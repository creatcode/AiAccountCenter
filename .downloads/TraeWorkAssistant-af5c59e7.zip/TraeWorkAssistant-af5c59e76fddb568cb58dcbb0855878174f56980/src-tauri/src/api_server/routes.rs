use std::borrow::Cow;
use std::collections::HashSet;
use std::io::Read;
use std::sync::{Arc, Mutex};

use axum::body::Body;
use axum::extract::State;
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::{Extension, Json};
use serde_json::{json, Value};
use tokio_stream::wrappers::ReceiverStream;

use super::custom_route;
use super::dispatch::{self, DispatchError, TargetPool};
use super::efforts;
use super::retry::{retry_plan, RetryAction};
use super::sse;
use super::unified_catalog;
use super::usage::{extract_tokens, KeyId};
use super::wb_catalog;
use super::wb_model_route;
use super::wb_route;
use super::wb_sticky::SessionKey;
use super::{classify_error, classify_solo_error, streaming_agent, ApiSharedState, ErrKind,
            InflightGuard,
            AGENT_HOST, APP_ID, EP_LLM_CHAT, IDE_VERSION, IDE_VERSION_CODE, REFERER_BASE};

const MAX_ROTATE: usize = 3;
/// 请求体上限（issue #21）：axum `Bytes` 提取器受 DefaultBodyLimit 约束（默认 2MiB），
/// build_router 已显式放开到本值，两处阈值必须一致。32MiB 适配长上下文客户端
/// （每轮重发完整历史 + 图片 base64 场景）
pub(super) const MAX_BODY_BYTES: usize = 32 << 20;

/// 请求体超限文案（issue #21）：由常量推导，避免阈值调整后文案脱节
pub(super) fn body_too_large_msg() -> String {
    format!("request body exceeds {}MB limit", MAX_BODY_BYTES >> 20)
}

/// 客户端协议：决定响应/流事件的输出格式（请求侧均已统一转为 OpenAI 内部格式）
#[derive(Clone, Copy, PartialEq)]
pub enum Protocol {
    OpenAi,
    /// OpenAI legacy text completions（/v1/completions）
    OpenAiText,
    Anthropic,
    /// Codex Responses API（/v1/responses，T4.1/F-40）
    Responses,
}

impl Protocol {
    pub(super) fn log_path(self) -> &'static str {
        match self {
            Protocol::OpenAi => "/v1/chat/completions",
            Protocol::OpenAiText => "/v1/completions",
            Protocol::Anthropic => "/v1/messages",
            Protocol::Responses => "/v1/responses",
        }
    }
}

/// 安全获取 Mutex 锁：若锁被毒化（panic 导致），仍恢复内部数据继续运行
fn safe_lock<'a, T>(m: &'a Mutex<T>) -> std::sync::MutexGuard<'a, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

/// keep-alive 退出信号（P1 修复）：主任务（spawn_blocking）结束时 Drop 触发
/// watch 通知，ticker 收到后退出 → sender 全部关闭 → 流可正常终结。
/// Drop 兜底覆盖 panic 展开与提前 return 路径。
/// pub(super)：WB / Custom 流式路径（wb_route.rs / custom_route.rs）复用同一方案
pub(super) struct DoneSignal(pub(super) tokio::sync::watch::Sender<bool>);

impl Drop for DoneSignal {
    fn drop(&mut self) {
        let _ = self.0.send(true);
    }
}

/// 聚合路径失败（P1 修复1）：区分「无健康账号」（维持原 503/格式）与
/// 「Fatal 上游错误透传」（携带上游状态码与错误体摘要）
enum AggregateFail {
    NoHealthy(String),
    Upstream(u16, String),
}

// ==================== Handlers ====================

/// WB 上游模型目录命中（T2.1 原始判定，保留供 /v1/models 与诊断复用）
#[allow(dead_code)]
fn wb_model_requested(state: &ApiSharedState, model: &str) -> bool {
    wb_catalog::find(&wb_catalog::load(&state.data_dir), model).is_some()
}

fn internal_error_response() -> Response {
    Response::builder()
        .status(StatusCode::INTERNAL_SERVER_ERROR)
        .body(Body::from("{\"error\":{\"message\":\"internal error\"}}"))
        .unwrap()
}

/// T5.2/F-61 四段模型路由解析（别名→规则→系列通配→后缀）+ T5.6③ 后台任务降级。
/// 返回 (最终模型, 路由级 effort 注入提示)；全未命中目录 → None（走 SOLO 上游）。
fn resolve_wb_target(
    state: &ApiSharedState,
    model: &str,
    body: &Value,
) -> Option<(String, Option<String>)> {
    let cfg = wb_model_route::load_config(&state.data_dir);
    let catalog = wb_catalog::load(&state.data_dir);
    let r = wb_model_route::resolve(&cfg, &catalog, model);
    if wb_catalog::find(&catalog, &r.model).is_none() {
        return None;
    }
    // T5.6③ 后台任务降级（显式开启才生效）：标题/摘要类短请求 → 目录最低倍率模型；
    // F-76④ 长上下文降档：输入粗估超阈值 → flash 档模型。
    // issue #26 白名单感知：降级候选 ∩ 白名单为空则跳过降级（原模型已过端点准入）
    let whitelist = unified_catalog::load_whitelist(&state.data_dir);
    let in_wl = |m: &str| unified_catalog::whitelist_allows(&whitelist, m);
    let final_model = if state.wb_bg_downgrade.load(std::sync::atomic::Ordering::Relaxed)
        && wb_model_route::is_background_task(body)
    {
        wb_model_route::cheapest_catalog_model_filtered(&catalog, &in_wl).unwrap_or(r.model)
    } else if state.wb_longctx_downgrade.load(std::sync::atomic::Ordering::Relaxed)
        && wb_model_route::estimate_input_tokens(body)
            >= wb_model_route::LONGCTX_TOKEN_THRESHOLD
    {
        wb_model_route::flash_catalog_model_filtered(&catalog, &in_wl).unwrap_or(r.model)
    } else {
        r.model
    };
    Some((final_model, r.effort_hint))
}

/// T5.3/F-62 默认深度思考：客户端未显式请求 effort 且无路由级提示时默认 high。
/// `explicit_effort` 由调用方按协议判定（OpenAI: reasoning_effort 字段；Anthropic: thinking 参数）
fn effective_effort_hint(
    state: &ApiSharedState,
    route_hint: Option<String>,
    explicit_effort: bool,
) -> Option<String> {
    if route_hint.is_some() {
        return route_hint;
    }
    if !explicit_effort
        && state
            .wb_default_thinking
            .load(std::sync::atomic::Ordering::Relaxed)
    {
        return Some("high".to_string());
    }
    None
}

/// 注入 effort 提示到请求体字节流（T5.2④/T5.3）
fn apply_effort_hint(body_vec: Vec<u8>, hint: Option<String>) -> Vec<u8> {
    wb_model_route::inject_effort_hint(&body_vec, &hint)
}

/// Trae 出站 effort wire 字段名（issue #31 T0.2 待确认）：
/// 2026-09 客户端抓包仅实证档位值（light/high/extra_high，efforts::TRAE_EFFORTS_REF），
/// 字段名以 T0.2 抓包为准，确认后仅需修改本常量。注入依赖上游「未知字段忽略」
/// 惯例，且仅实证表内模型才产生 wire 值（表外不下发，不按名称猜测）
const TRAE_EFFORT_FIELD: &str = "reasoning_effort_level";

/// Trae 池 effort 解析（issue #31 T3.2/T3.3）：显式请求 > 路由级提示（后缀剥离
/// 所得）> 默认深度思考，三源合成为统一档位后转 Trae wire（efforts::trae_request_wire：
/// 实证表内精确命中或按降级链取兼容值）。
/// 实证表外模型（如档位仅 Buddy 侧声明、Trae 无实证）：显式客户端请求按统一→
/// Trae 映射填充默认下发（efforts::trae_request_wire_fill）；合成默认（路由提示/
/// 默认深度思考）不下发，保守走上游默认。
/// 显式关闭以空串编码（Anthropic thinking disabled）：短路默认思考与路由提示
fn trae_effort_wire(
    state: &ApiSharedState,
    route_hint: Option<String>,
    explicit: Option<String>,
    model: &str,
) -> Option<String> {
    let supported = efforts::trae_supported_wire(&unified_catalog::canonical_id(model));
    // 合成请求侧档位：显式 > 路由提示 > 全局默认思考（表外模型仅显式参与填充）。
    // 日志需记合成后的 requested 而非仅 explicit，否则 route_hint/默认思考生效时
    // 日志与实际出站不符
    let requested = if supported.is_empty() {
        explicit.clone()
    } else {
        explicit.clone().or(route_hint).or_else(|| {
            state
                .wb_default_thinking
                .load(std::sync::atomic::Ordering::Relaxed)
                .then(|| "high".to_string())
        })
    };
    let wire = if supported.is_empty() {
        // 表外无实证：仅显式请求填充默认（统一→Trae 映射），合成默认不下发
        efforts::trae_request_wire_fill(explicit.as_deref())
    } else {
        requested
            .as_deref()
            .and_then(|req| efforts::trae_request_wire(Some(req), &supported))
    };
    // 可观测性（issue #38-5）：请求侧档位 → wire 档位映射落盘（脱敏，仅模型与档位），
    // 用于验证「档位到底有没有下发/映射成哪一档」
    crate::fs_utils::app_log(
        &state.data_dir,
        &format!(
            "trae effort: model={} requested={:?} wire={:?}",
            model, requested, wire
        ),
    );
    wire
}

/// Trae 出站 Max Mode 字段名（issue #31 T4.2，T0.3 客户端实证）：请求级布尔门控。
/// 注入值用布尔 true（2026-09-26 真机实证 is_max_mode:true + pmt:168000 → 200）。
/// 注意：issue #38 报告的 4001 真机根因是 body model 字段未随 `-max` 剥离回写
/// （见 inject_trae_outbound），字段值类型并非根因。仅入口标志置位且模型在
/// 支持表内才注入（表外不冒进）
const TRAE_MAX_MODE_FIELD: &str = "is_max_mode";

/// Trae 出站注入（issue #31 T3.3/T4.2）：effort wire 与 Max Mode 两路合并为单次
/// parse/serialize（Max Mode 场景恰为大 body，避免重复往返）。同时回写 body 的
/// model 字段为剥离后基名（issue #38 真机根因：dispatch 剥离 `-max`/`-thinking`
/// 仅用于路由与日志，body 原样透传致 payload 生成 `xxx-max__dev` → 上游 4001
/// param invalid）。三者均未激活时零 parse 原样返回；非对象/非 JSON body 原样返回。
/// payload 层（prepare_llm_chat_body）为透传+增补模式，注入字段直达上游。
/// 注入结果落 app.log（issue #38-5：is_max_mode 是否注入此前无任何痕迹，
/// 无法区分「注入被拒」与「后缀未剥离」）
fn inject_trae_outbound(
    data_dir: &std::path::Path,
    body_vec: Vec<u8>,
    wire: Option<String>,
    max_mode_hint: bool,
    requested_model: &str,
    model: &str,
) -> Vec<u8> {
    let inject_max =
        max_mode_hint && efforts::trae_max_mode_supported(&unified_catalog::canonical_id(model));
    let rewrite_model = requested_model != model;
    if wire.is_none() && !inject_max && !rewrite_model {
        return body_vec;
    }
    match serde_json::from_slice::<Value>(&body_vec) {
        Ok(Value::Object(mut obj)) => {
            if rewrite_model {
                obj.insert("model".into(), json!(model));
            }
            if let Some(w) = &wire {
                obj.insert(TRAE_EFFORT_FIELD.to_string(), json!(w));
            }
            if inject_max {
                obj.insert(TRAE_MAX_MODE_FIELD.to_string(), json!(true));
            }
            crate::fs_utils::app_log(
                data_dir,
                &format!(
                    "trae outbound: model={} requested_model={} effort_injected={} max_mode_injected={}",
                    model,
                    requested_model,
                    wire.is_some(),
                    inject_max,
                ),
            );
            serde_json::to_vec(&obj).unwrap_or(body_vec)
        }
        _ => body_vec,
    }
}

/// 模型级冷却快速失败（T2.7/F-34：优先级高于 Key 级）
fn model_cooling_response(state: &ApiSharedState, model: &str, proto: Protocol) -> Response {
    let rem = wb_route::model_cooling_remaining(state, model).unwrap_or(0);
    let msg = format!("model {} cooling down, retry after {}s", model, rem);
    match proto {
        Protocol::Anthropic => anthropic_error(StatusCode::TOO_MANY_REQUESTS, "rate_limit_error", &msg),
        _ => openai_error(StatusCode::TOO_MANY_REQUESTS, "model_cooldown", &msg),
    }
}

/// 调度错误矩阵 → 按客户端协议格式化响应（§4.3/§4.5；统一调度分流点专用）。
/// issue #29 修复1：调度阶段失败同样落 API 请求日志——此前失败仅 app.log 有
/// dispatch exhausted，前端「API 请求日志」页无记录，用户无法自查失败原因。
/// pub(crate)：dispatch 测试模块经 Fixture 直测日志落盘（与 no_healthy_detail 同模式）
pub(crate) fn dispatch_error_response(
    state: &ApiSharedState,
    err: DispatchError,
    proto: Protocol,
    model: &str,
    stream: bool,
    key_str: &str,
    duration_ms: u64,
) -> Response {
    // 单次 match：错误 → (状态码, 池标识, 消息, OpenAI 侧错误码, Anthropic 侧错误码)
    let (status, pool_str, msg, oa_code, anthro_code): (StatusCode, &str, String, &'static str, &'static str) =
        match err {
            DispatchError::WbDisabled => (
                StatusCode::BAD_REQUEST,
                "buddy",
                "该模型属 WorkBuddy 上游，但 WB 上游未启用（api_pool.json wb_enabled）".to_string(),
                "wb_upstream_disabled",
                "invalid_request_error",
            ),
            DispatchError::QoderDisabled => (
                StatusCode::BAD_REQUEST,
                "qoder",
                "该模型属 Qoder 上游，但 Qoder 上游未启用（api_pool.json qoder_enabled）".to_string(),
                "qoder_upstream_disabled",
                "invalid_request_error",
            ),
            DispatchError::TraeDisabled => (
                StatusCode::BAD_REQUEST,
                "trae",
                "该模型属 Trae 上游，但 Trae 资源池已停用（api_pool.json trae_enabled）".to_string(),
                "trae_pool_disabled",
                "invalid_request_error",
            ),
            DispatchError::ModelCooling(rem) => (
                StatusCode::TOO_MANY_REQUESTS,
                "buddy",
                format!("model {model} cooling down, retry after {rem}s"),
                "model_cooldown",
                "rate_limit_error",
            ),
            DispatchError::NoHealthy(pool) => (
                StatusCode::SERVICE_UNAVAILABLE,
                pool.as_str(),
                no_healthy_detail(state, pool, key_str),
                "no_healthy_account",
                "api_error",
            ),
        };
    // issue #29 修复1：uid/acct 置空（调度阶段未取号），error 携带失败原因
    let key_name = super::api_keys::key_name_for(&state.data_dir, key_str);
    state.logger.log_request(
        pool_str, "POST", proto.log_path(), model, stream, status.as_u16(), "-",
        duration_ms, &key_name, "", Some(&msg),
    );
    match proto {
        Protocol::Anthropic => anthropic_error(status, anthro_code, &msg),
        _ => openai_error(status, oa_code, &msg),
    }
}

/// 轮换耗尽收尾文案（issue #57 后续可观测）：区分「渠道指纹拦截」与「账号池耗尽」。
/// 空完成（影子风控，HTTP 200 零内容）与账号无关，换号轮换打满整池后原文案
/// "no healthy account available" 会误导用户排查账号——现按 empty_hits 分流：
/// 空完成主导（过半轮换账号返回空完成）→ 明示指纹拦截语义（账号/模型无关，
/// 提示更新清洗规则表）；混合失败（空完成仅零星出现、以限流/5xx 为主）时
/// 维持原文案，避免 "switching won't help" 误导排障方向。返回 (错误消息, 诊断日志标记)
pub(crate) fn exhaust_message(empty_hits: usize, rotated: usize, healthy_total: usize) -> (String, &'static str) {
    if rotated > 0 && empty_hits * 2 > rotated {
        (
            format!(
                "channel fingerprint block suspected: {empty_hits} empty completion(s) across {rotated} rotated accounts (Trae shadow risk control, account/model agnostic — switching won't help); try updating wb_template_map.json or enabling sanitize (pool=trae healthy={healthy_total})",
            ),
            "CHANNEL_FINGERPRINT_BLOCK",
        )
    } else {
        (
            "no healthy account available".to_string(),
            "NO_HEALTHY_ACCOUNT",
        )
    }
}

/// NoHealthy 详情（issue #29 修复2）：错误消息携带 Key 约束细节（绑定池/白名单
/// 条数/专一账号）与池内健康计数，帮助用户自查 Key 配置（匿名/未知 Key 仅报
/// 池健康数）；healthy_in_scope 为约束作用域内健康账号数，0 即「约束排除致败」。
/// pub(crate)：dispatch 测试模块经 Fixture 直测（与 trae_pool_constraints 同模式）
pub(crate) fn no_healthy_detail(state: &ApiSharedState, pool: TargetPool, key_str: &str) -> String {
    let pool_ref = match pool {
        TargetPool::Trae => &state.pool,
        TargetPool::Buddy => &state.wb_pool,
        TargetPool::Qoder => &state.qoder_pool,
        // 不可达：custom 在 resolve_target 顶部短路返回（匹配穷尽兜底）
        TargetPool::Custom => return "no healthy account available".to_string(),
    };
    let (healthy_total, _) = pool_ref.selectable_stats_in(None);
    let base = format!(
        "no healthy account available (pool={} healthy={healthy_total})",
        pool.as_str(),
    );
    // 单锁快照：一次取（展示名, 约束），替代 constraints_for + key_name_for 双加锁
    let Some((name, rk)) = super::api_keys::key_snapshot_for(&state.data_dir, key_str) else {
        return base;
    };
    let name = if name.is_empty() { key_str } else { name.as_str() };
    let bind = rk.bind_pool().unwrap_or("-");
    match rk.pool_constraints(pool.as_str()) {
        None => format!("{base} key={name} bind={bind} constraint=none"),
        Some(c) => {
            let (_, healthy_scope) = pool_ref.selectable_stats_in(c.allowed.as_ref());
            let wl = match &c.allowed {
                None => "none".to_string(),
                Some(s) => s.len().to_string(),
            };
            let ded = c.dedicated.as_deref().unwrap_or("-");
            format!(
                "{base} key={name} bind={bind} whitelist={wl} dedicated={ded} healthy_in_scope={healthy_scope}"
            )
        }
    }
}

/// issue #26 全局模型白名单准入：请求模型不在白名单时返回按协议格式化的 404。
/// 拒绝码与官方语义一致：OpenAI 侧 `model_not_found`、Anthropic 侧 `not_found_error`。
/// 白名单为空 = 不限（默认行为零变化）
fn whitelist_check(state: &ApiSharedState, model: &str, proto: Protocol) -> Option<Response> {
    let list = unified_catalog::load_whitelist(&state.data_dir);
    if unified_catalog::whitelist_allows(&list, model) {
        return None;
    }
    // issue #90 修复③a：池前缀模型 id（trae/xxx 等）按裸名准入——dispatch 与
    // /v1/models 别名条目使用同一前缀语义，启用白名单的部署不得在准入层拦截。
    // 分层检查：先原始名（覆盖白名单字面量含前缀条目的配置），再裸名兜底；
    // 拒绝信息保留用户请求的原始名（显示裸名会让人误以为请求的是另一个模型）
    let bare = super::dispatch::split_pool_prefix(model).map(|(_, bare)| bare);
    if let Some(bare) = bare {
        if unified_catalog::whitelist_allows(&list, bare) {
            return None;
        }
    }
    // C1（审查修复）：后缀剥离仅按裸名段进行；拒绝信息保留用户请求的原始名
    // （含前缀）——修复此前 `let model = bare.unwrap_or(model)` 遮蔽导致 404
    // 文案显示裸名、与上方注释「保留原始名」矛盾的问题（放行/剥离逻辑不变）
    let stripped = bare.unwrap_or(model);
    // issue #38 实测修复：`-max` / `-thinking` 等入口后缀在 dispatch ② 段才剥离，
    // 白名单须按同一剥离规则对基名放行——否则启用白名单的部署下，Max Mode /
    // 路由后缀入口在准入层就被 404 拦截，整个能力不可用（剥离规则与 dispatch 同源，
    // 基名最终可服务性仍由 dispatch 查模型列表判定，此处仅准入放行）
    let cfg = wb_model_route::load_config(&state.data_dir);
    let bases = [
        wb_model_route::strip_max_suffix(stripped),
        wb_model_route::strip_route_suffix(stripped, &cfg).map(|(b, _)| b),
    ];
    for base in bases.into_iter().flatten() {
        if unified_catalog::whitelist_allows(&list, &base) {
            return None;
        }
    }
    Some(whitelist_error_response(model, proto))
}

/// 白名单拒绝响应壳（独立纯函数便于单测错误格式）
fn whitelist_error_response(model: &str, proto: Protocol) -> Response {
    let msg = format!(
        "model {} is not in the model whitelist; see GET /v1/models for allowed models",
        model
    );
    match proto {
        Protocol::Anthropic => anthropic_error(StatusCode::NOT_FOUND, "not_found_error", &msg),
        _ => openai_error(StatusCode::NOT_FOUND, "model_not_found", &msg),
    }
}

pub async fn health(State(state): State<Arc<ApiSharedState>>) -> impl IntoResponse {
    // 收敏（2026-10-12 审查 P2）：/health 在 auth.rs 免鉴权放行（探活豁免），
    // 原实现透出 total_credits/active_uid/last_error/池账号数——非环回监听时
    // 局域网内无 Key 即可抓取账号与积分画像，与「非环回强制鉴权」防线矛盾。
    // 探活只需存活布尔；完整诊断由需鉴权的 GET /status 承载（字段超集）
    let _ = &state;
    Json(json!({
        "status": "ok",
        "running": true,
    }))
}

/// /healthz（T2.3/F-32）：无健康账号（两个池都没有）→ 503，供探活/看门狗
pub async fn healthz(State(state): State<Arc<ApiSharedState>>) -> Response {
    let pool = state.pool.status_list();
    let wb_pool = state.wb_pool.status_list();
    let solo_ok = pool.iter().any(|p| !p.disabled && !p.cooling);
    let wb_enabled = state.wb_enabled.load(std::sync::atomic::Ordering::Relaxed);
    let wb_ok = wb_pool.iter().any(|p| !p.disabled && !p.cooling);
    if solo_ok || (wb_enabled && wb_ok) {
        (
            StatusCode::OK,
            axum::Json(json!({ "status": "ok", "solo_available": solo_ok, "wb_available": wb_ok })),
        )
            .into_response()
    } else {
        (
            StatusCode::SERVICE_UNAVAILABLE,
            axum::Json(json!({ "status": "unavailable", "reason": "no healthy account" })),
        )
            .into_response()
    }
}

pub async fn status(State(state): State<Arc<ApiSharedState>>) -> impl IntoResponse {
    let pool = state.pool.status_list();
    let now: i64 = now_ts() as i64;
    let total = state.total_requests.load(std::sync::atomic::Ordering::Relaxed);
    let active = safe_lock(&state.active_uid).clone();
    let last_err = safe_lock(&state.last_error).clone();

    // 汇总统计
    let total_accounts = pool.len();
    let available = pool.iter().filter(|p| !p.disabled && !p.cooling).count();
    let cooling = pool.iter().filter(|p| p.cooling).count();
    let disabled = pool.iter().filter(|p| p.disabled).count();
    let total_credits: f64 = pool.iter().filter_map(|p| p.credits).sum();
    let total_credits = (total_credits * 100.0).round() / 100.0;

    // 账号明细（inflight 为 F-77 账号级实时并发）
    let accounts: Vec<Value> = pool.iter().map(|p| {
        let status = if p.disabled {
            "disabled"
        } else if p.cooling {
            "cooling"
        } else if p.credits_expire_at.map_or(false, |exp| exp < now) {
            "expired"
        } else if p.credits.map_or(false, |c| c <= 0.0) {
            "no_credits"
        } else {
            "available"
        };
        json!({
            "uid": p.uid,
            "name": p.name,
            "status": status,
            "credits": p.credits,
            "credits_expire_at": p.credits_expire_at,
            "cooling": p.cooling,
            "cooldown_until": p.cooldown_until,
            "cooldown_reason": p.cooldown_reason,
            "disabled": p.disabled,
            "err_count": p.err_count,
            "state": p.state,
            "inflight": p.inflight,
        })
    }).collect();

    // WB 池画像（T2.3/F-32；inflight 为 F-77 账号级实时并发）
    let wb_pool = state.wb_pool.status_list();
    let wb_enabled = state.wb_enabled.load(std::sync::atomic::Ordering::Relaxed);
    let wb_accounts: Vec<Value> = wb_pool.iter().map(|p| {
        json!({
            "uid": p.uid, "name": p.name, "credits": p.credits,
            "cooling": p.cooling, "cooldown_until": p.cooldown_until,
            "cooldown_reason": p.cooldown_reason, "disabled": p.disabled,
            "err_count": p.err_count, "state": p.state, "inflight": p.inflight,
        })
    }).collect();
    // F-77：per-account 并发列表（活跃账号 [{uid, name, inflight}]），
    // 供前端池状态页实时展示 busy/idle 分布（active_uid 单值的超集）
    let active_accounts: Vec<Value> = pool
        .iter()
        .chain(wb_pool.iter())
        .filter(|p| p.inflight > 0)
        .map(|p| json!({ "uid": p.uid, "name": p.name, "inflight": p.inflight }))
        .collect();
    let model_cooldowns: Vec<Value> = {
        let map = safe_lock(&state.model_cooldowns);
        map.iter()
            .filter(|(_, (until, _))| *until > now)
            .map(|(m, (until, fails))| json!({
                "model": m, "until": until, "remaining_s": until - now, "fails": fails,
            }))
            .collect()
    };

    Json(json!({
        "running": true,
        "total_requests": total,
        // 当前并发数（统一网关 §4.5）：InflightGuard RAII 维护，覆盖 6 业务端点
        "inflight": state.inflight.load(std::sync::atomic::Ordering::Relaxed),
        "active_uid": active,
        // F-77：per-account 并发列表（busy 账号实时画像）
        "active_accounts": active_accounts,
        "last_error": last_err,
        "summary": {
            "total_accounts": total_accounts,
            "available": available,
            "cooling": cooling,
            "disabled": disabled,
            "total_credits": total_credits,
        },
        "accounts": accounts,
        "wb": {
            "enabled": wb_enabled,
            "total_accounts": wb_pool.len(),
            "accounts": wb_accounts,
            "model_cooldowns": model_cooldowns,
            "sticky_sessions": state.wb_sticky.len(),
            // 上游健康探针（F-34 ④/§2.2）：-1 未探测 / 0 不可达 / 1 在线
            "probe_ok": state.wb_probe_ok.load(std::sync::atomic::Ordering::Relaxed),
            "probe_ts_ms": state.wb_probe_ts_ms.load(std::sync::atomic::Ordering::Relaxed),
        },
    }))
}

pub async fn models(State(state): State<Arc<ApiSharedState>>) -> impl IntoResponse {
    // 统一模型目录（§3.4）：实时聚合 data/api_models.json（Trae，元数据四层链）
    // 与 data/wb_model_catalog.json（Buddy），纯派生不落盘。官网/目录同步后
    // 无需重启 API 服务即可通过 /v1/models 看到最新列表
    let wb_enabled = state.wb_enabled.load(std::sync::atomic::Ordering::Relaxed);
    // 可用性标记运行时派生（§3.3 #5）：HTTP 端点用实时池健康；
    // Trae 开关（trae_enabled，默认开）参与徽章判定——关闭时 Trae 源徽章置灰
    let trae_enabled = state.trae_enabled.load(std::sync::atomic::Ordering::Relaxed);
    let trae_ok = trae_enabled && state.pool.has_selectable();
    let buddy_ok = state.wb_pool.has_selectable();
    // Qoder 源旗标（p3-3）：条目始终入表（开关关闭时徽章置灰）
    let qoder_enabled = state.qoder_enabled.load(std::sync::atomic::Ordering::Relaxed);
    let qoder_ok = state.qoder_pool.has_selectable();
    let data_dir = state.data_dir.clone();
    // issue #90 修复③a：来源标识开关（dispatch_policy.model_source_labels）——
    // 开启后为多源同名模型附带池前缀别名条目（trae/xxx / buddy/xxx / qoder/xxx），
    // 客户端（如 CC Switch）可在同名模型间区分来源池（三家倍率与效果不同）
    let source_labels = dispatch::load_policy(&data_dir).model_source_labels;
    let list = tokio::task::spawn_blocking(move || {
        // issue #26：对外目录经全局白名单过滤（管理端 api_unified_models 不过滤）
        unified_catalog::unified_models_whitelisted_ex(
            &data_dir,
            wb_enabled,
            trae_ok,
            buddy_ok,
            Some((qoder_enabled, qoder_ok)),
        )
    })
    .await
    .unwrap_or_default();
    // wb_enabled=false：仅 Buddy 源的模型过滤，双源模型保留（仍可由 Trae 源服务 §3.4）
    let mut data: Vec<Value> = list
        .iter()
        .filter(|m| wb_enabled || !m.sources.iter().all(|s| s.pool == "buddy"))
        .map(|m| {
            json!({
                "id": m.id,
                "object": "model",
                "created": 1753600000,
                "owned_by": "unified",
                "display": m.display,
                "rate": m.rate,
                "context_length": m.context_length,
                "max_tokens": m.max_tokens,
                "supports_image": m.supports_image,
                "supported_efforts": m.efforts,
                // Max Mode 支持（issue #38-1：UnifiedModel 已按支持表计算，
                // 此前手工序列化遗漏导致 release notes/手册声明的字段从未出现在响应中）
                "max_mode": m.max_mode,
                // 来源池集合：[{pool: "trae"|"buddy", rate, enabled}]（徽章/降级判定
                // 由客户端按元数据自决，勿硬编码 §3.4）
                "sources": m.sources,
                "manual": m.manual,
            })
        })
        .collect();
    // issue #90 修复③a：多源同名模型的池前缀别名条目（开关开启时追加，不改写
    // 原有 id——已有客户端零影响）。带前缀 id 请求经 resolve_target 锁定该池，
    // 白名单按裸名放行（whitelist_check 同步剥离）；别名条目随基础条目白名单
    // 过滤结果派生，不重复过滤
    if source_labels {
        for m in list.iter().filter(|m| m.sources.len() >= 2) {
            for s in m.sources.iter().filter(|s| s.pool != "custom") {
                data.push(json!({
                    "id": format!("{}/{}", s.pool, m.id),
                    "object": "model",
                    "created": 1753600000,
                    "owned_by": "unified",
                    "display": format!("[{}] {}", s.pool, m.display),
                    "rate": s.rate,
                    "context_length": m.context_length,
                    "max_tokens": m.max_tokens,
                    "supports_image": m.supports_image,
                    "supported_efforts": m.efforts,
                    "max_mode": m.max_mode,
                    "sources": m.sources,
                    // 别名标记：客户端可据此折叠展示；source_pool = 该 id 实际锁定的池
                    "alias_of": m.id,
                    "source_pool": s.pool,
                    "manual": m.manual,
                }));
            }
        }
    }
    Json(json!({ "object": "list", "data": data }))
}

pub async fn chat_completions(
    State(state): State<Arc<ApiSharedState>>,
    key_id: Option<Extension<KeyId>>,
    headers: axum::http::HeaderMap,
    body: axum::body::Bytes,
) -> Response {
    if body.len() > MAX_BODY_BYTES {
        return openai_error(
            StatusCode::PAYLOAD_TOO_LARGE,
            "request_too_large",
            &body_too_large_msg(),
        );
    }

    // T5.6② 单端口协议区分：anthropic-version 头出现 → 客户端实为 Anthropic
    // Messages 协议，按路径分流给出明确指引（避免三协议混投后字段级静默错乱）
    if headers.contains_key("anthropic-version") {
        return openai_error(
            StatusCode::BAD_REQUEST,
            "wrong_endpoint",
            "检测到 anthropic-version 头：该请求应为 Anthropic Messages 协议，请改用 POST /v1/messages（本网关单端口三协议按路径区分）",
        );
    }

    state
        .total_requests
        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);

    let body_vec = body.to_vec();
    // 校验 JSON：无效请求体直接 400，不转发上游（与 /v1/messages 行为对齐）
    let peek: Value = match serde_json::from_slice(&body_vec) {
        Ok(v) => v,
        Err(e) => {
            return openai_error(
                StatusCode::BAD_REQUEST,
                "invalid_request_error",
                &format!("invalid JSON body: {}", e),
            )
        }
    };
    let stream = peek.get("stream").and_then(|v| v.as_bool()).unwrap_or(false);
    let model = peek
        .get("model")
        .and_then(|v| v.as_str())
        .filter(|s| !s.trim().is_empty())
        .unwrap_or(&state.default_model)
        .to_string();
    // issue #26 白名单准入（空名单不限）
    if let Some(resp) = whitelist_check(&state, &model, Protocol::OpenAi) {
        return resp;
    }
    let state_clone = state.clone();
    let start_ts = std::time::Instant::now();
    let key_str = key_id.map(|Extension(k)| k.0).unwrap_or_else(|| "anonymous".to_string());

    // 统一调度分流点（§4.1 ③~⑥）：resolve_target 决定资源池/会话池粘性/跨池回退/
    // 错误矩阵，替代原 resolve_wb_target 单向判定；默认策略下行为与改造前一致（§9.1）。
    // inflight guard 随执行路径持有至请求结束（流式含整个后台任务）
    let guard = state.inflight_guard();
    match dispatch::resolve_target(&state, &model, &peek, Some(&key_str)) {
        Err(e) => dispatch_error_response(
            &state, e, Protocol::OpenAi, &model, stream, &key_str,
            start_ts.elapsed().as_millis() as u64,
        ),
        Ok(r) => match r.pool {
            TargetPool::Buddy => {
                // T5.3 默认深度思考：客户端未带 reasoning_effort 时注入 high
                let explicit = peek.get("reasoning_effort").and_then(|v| v.as_str()).is_some();
                let hint = effective_effort_hint(&state, r.effort_hint, explicit);
                let body_vec = apply_effort_hint(body_vec, hint);
                if stream {
                    return wb_route::wb_stream_chat(state_clone, body_vec, r.model, start_ts, Protocol::OpenAi, key_str, guard);
                }
                return wb_route::wb_aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAi, key_str, guard).await;
            }
            TargetPool::Qoder => {
                // Qoder 上游（p3-3）：请求体由执行路径按目录条目构造（agent 信封），
                // 无 effort/后缀预处理（思考档位由 resolve_thinking 按条目解析）
                if stream {
                    return super::qoder_route::qoder_stream_chat(state_clone, body_vec, r.model, start_ts, Protocol::OpenAi, key_str, guard);
                }
                return super::qoder_route::qoder_aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAi, key_str, guard).await;
            }
            TargetPool::Trae => {
                // issue #31 T3.2/T3.3：Trae 池 effort 通道（默认思考两池对齐）——
                // 显式 reasoning_effort / 路由级提示 / 默认思考 → wire 档位注入
                let explicit = peek
                    .get("reasoning_effort")
                    .and_then(|v| v.as_str())
                    .map(str::to_string);
                let wire = trae_effort_wire(&state, r.effort_hint, explicit, &r.model);
                let body_vec = inject_trae_outbound(
                    &state.data_dir, body_vec, wire, r.max_mode_hint, &model, &r.model,
                );
                if stream {
                    stream_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAi, key_str, guard)
                } else {
                    aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAi, key_str, guard).await
                }
            }
            TargetPool::Custom => {
                // 自定义模型直达（custom_models 命中即 Custom，§dispatch ⓪）；
                // 条目可能热更新，执行时重读，缺失（已被删）按 404 语义报错
                match super::custom_models::find_enabled(&state.data_dir, &model) {
                    Some(cm) => {
                        if stream {
                            custom_route::custom_stream_chat(state_clone, body_vec, r.model, cm, start_ts, Protocol::OpenAi, key_str, guard)
                        } else {
                            custom_route::custom_aggregate_chat(state_clone, body_vec, r.model, cm, stream, start_ts, Protocol::OpenAi, key_str, guard).await
                        }
                    }
                    None => openai_error(StatusCode::NOT_FOUND, "model_not_found", &format!("自定义模型 {} 已被删除", model)),
                }
            }
        },
    }
}

/// Codex Responses API 端点（T4.1/F-40）：POST /v1/responses
///
/// 请求投影为 OpenAI 内部格式后复用 WB 上游既有管线（取号/重试/粘性/脱敏一份）。
/// 仅支持 WB 上游模型（Codex CLI `wire_api="responses"` 直配 base_url 的目标场景）；
/// 脱敏沿用全局 `wb_sanitize` 开关，审核命中按既有分级重试表退回重试。
pub async fn responses_api(
    State(state): State<Arc<ApiSharedState>>,
    key_id: Option<Extension<KeyId>>,
    body: axum::body::Bytes,
) -> Response {
    if body.len() > MAX_BODY_BYTES {
        return openai_error(
            StatusCode::PAYLOAD_TOO_LARGE,
            "request_too_large",
            &body_too_large_msg(),
        );
    }

    state
        .total_requests
        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);

    let peek: Value = match serde_json::from_slice(&body) {
        Ok(v) => v,
        Err(e) => {
            return openai_error(
                StatusCode::BAD_REQUEST,
                "invalid_request_error",
                &format!("invalid JSON body: {}", e),
            )
        }
    };
    let stream = peek.get("stream").and_then(|v| v.as_bool()).unwrap_or(false);
    let model = peek
        .get("model")
        .and_then(|v| v.as_str())
        .filter(|s| !s.trim().is_empty())
        .unwrap_or(&state.default_model)
        .to_string();
    // issue #26 白名单准入（空名单不限）
    if let Some(resp) = whitelist_check(&state, &model, Protocol::Responses) {
        return resp;
    }

    // Responses → OpenAI chat 内部格式（纯投影，失败即 400）
    let chat_body: Value = match super::wb_responses::responses_to_chat(&peek) {
        Ok(v) => v,
        Err(e) => {
            return openai_error(StatusCode::BAD_REQUEST, "invalid_request_error", &e);
        }
    };

    let state_clone = state.clone();
    let start_ts = std::time::Instant::now();
    let key_str = key_id.map(|Extension(k)| k.0).unwrap_or_else(|| "anonymous".to_string());
    // inflight guard：随执行路径持有至请求结束（§4.5）
    let guard = state.inflight_guard();

    // T5.2/F-61 四段路由解析（Responses 仅支持 WB 上游模型）
    let (resolved_model, route_hint) = match resolve_wb_target(&state, &model, &chat_body) {
        Some(t) => t,
        None => {
            return openai_error(
                StatusCode::BAD_REQUEST,
                "model_not_found",
                &format!(
                    "model {} is not a WorkBuddy upstream model（/v1/responses 仅支持 WB 上游模型，目录见 /v1/models）",
                    model
                ),
            );
        }
    };
    if !state.wb_enabled.load(std::sync::atomic::Ordering::Relaxed) {
        return openai_error(
            StatusCode::BAD_REQUEST,
            "wb_upstream_disabled",
            "WB 上游未启用（api_pool.json wb_enabled）",
        );
    }
    if wb_route::model_cooling_remaining(&state, &resolved_model).is_some() {
        return model_cooling_response(&state, &resolved_model, Protocol::Responses);
    }

    let mut chat_body = chat_body;
    // T5.5/F-64 工具代执行：客户端声明 web_search 类工具且开关开启 → 代理侧代执行编排
    if state.wb_tool_exec.load(std::sync::atomic::Ordering::Relaxed)
        && super::wb_toolexec::responses_declares_web_search(&peek)
    {
        return wb_route::wb_tool_exec_chat(
            state_clone,
            chat_body,
            resolved_model,
            stream,
            start_ts,
            key_str,
            guard,
        )
        .await;
    }
    chat_body["stream"] = json!(stream);
    // T5.3 默认深度思考（Responses: reasoning.effort 已投影为 reasoning_effort）
    let explicit = chat_body.get("reasoning_effort").and_then(|v| v.as_str()).is_some();
    let hint = effective_effort_hint(&state, route_hint, explicit);
    let body_vec = apply_effort_hint(serde_json::to_vec(&chat_body).unwrap_or_default(), hint);

    if stream {
        wb_route::wb_stream_chat(state_clone, body_vec, resolved_model, start_ts, Protocol::Responses, key_str, guard)
    } else {
        wb_route::wb_aggregate_chat(state_clone, body_vec, resolved_model, stream, start_ts, Protocol::Responses, key_str, guard).await
    }
}

// ==================== issue #54 Claude Code 分类器模型兜底 ====================

/// 剥离模型名尾部的 `[1m]` 窗口标记（Claude 1M 上下文变体后缀），ASCII 大小写不敏感。
/// 纯字节尾比较：`[1m]` 全 ASCII（<0x80），不可能与多字节 UTF-8 尾字节混淆，
/// 切分点必为字符边界（'[' 起点）——任何输入不 panic。不引入 to_lowercase
/// 字节漂移（对照 wb_model_route::strip_suffix_ci 审查修复的同类切片问题）；
/// 仅识别尾部完整标记且剥离后非空
fn strip_bracket_1m(name: &str) -> Option<&str> {
    const SUFFIX: &[u8] = b"[1m]";
    let bytes = name.as_bytes();
    // 短路顺序保证：len > 4 先于切片，不会下溢
    if bytes.len() > SUFFIX.len()
        && bytes[bytes.len() - SUFFIX.len()..].eq_ignore_ascii_case(SUFFIX)
    {
        Some(&name[..bytes.len() - SUFFIX.len()])
    } else {
        None
    }
}

/// 三池可路由判定（Anthropic 入口兜底专用）：Custom 直达命中 /
/// WB 路由解析命中目录且上游启用 / Trae 模型列表 canonical 命中
fn anthropic_model_servable(state: &ApiSharedState, model: &str) -> bool {
    if super::custom_models::find_enabled(&state.data_dir, model).is_some() {
        return true;
    }
    let cfg = wb_model_route::load_config(&state.data_dir);
    let catalog = wb_catalog::load(&state.data_dir);
    let r = wb_model_route::resolve(&cfg, &catalog, model);
    if state.wb_enabled.load(std::sync::atomic::Ordering::Relaxed)
        && wb_catalog::find(&catalog, &r.model).is_some()
    {
        return true;
    }
    super::models_sync::load_models(&state.data_dir)
        .iter()
        .any(|m| unified_catalog::canonical_id(&m.id) == unified_catalog::canonical_id(model))
}

/// Claude Code auto 模式（v2.1.83+）把权限审批交给独立「安全分类器」模型：
/// 分类器以 side_query 请求本网关 `/v1/messages`，模型名为 Claude Code 服务端
/// feature flag 下发的官方名（如 `claude-sonnet-5[1m]`）——无环境变量可覆盖，
/// 三池不可路由时上游必 4001/失败，Claude Code 随即 fail-closed 报
/// "temporarily unavailable (timed out)" 并阻断 Bash/Write（issue #54）。
///
/// 入口兜底：原名可路由 → 原样（WB 用户经内置系列 claude-* 映射的行为不变）；
/// 剥离 `[1m]` 标记后基名可路由 → 用基名；仍不可路由的 `claude-*` 系名
/// （Anthropic 内部名，上游不可能服务）回落网关默认模型。
/// 返回 Some(改写后模型名)；None = 原样保留（非 claude 未知名维持透传语义）
fn anthropic_model_fallback(state: &ApiSharedState, model: &str) -> Option<String> {
    let m = model.trim();
    if m.is_empty() {
        return None;
    }
    // 热路径短路（零分配）：仅 claude-* 系名与带 [1m] 窗口标记的请求参与判定
    let bytes = m.as_bytes();
    let is_claude = bytes.len() >= 6 && bytes[..6].eq_ignore_ascii_case(b"claude");
    let has_1m = strip_bracket_1m(m).is_some();
    if !is_claude && !has_1m {
        return None;
    }
    // ① 原名可路由（含 Custom 命中、WB 系列映射命中且启用）→ 原样保留
    if anthropic_model_servable(state, m) {
        return None;
    }
    // ② 剥 [1m] 后基名可路由（如用户以基名配置了 Custom claude 条目）→ 用基名
    if let Some(base) = strip_bracket_1m(m) {
        if anthropic_model_servable(state, base) {
            return Some(base.to_string());
        }
    }
    // ③ claude-* 系不可路由 → 回落网关默认模型；非 claude 未知名维持透传
    //（与 dispatch t07 透传语义零行为差异）。边界：默认模型自身不可服务时
    // 不再二次改写，与「未指定 model 的请求」走同一失败路径，行为一致
    let default = state.default_model.trim();
    if is_claude && !default.is_empty() && !default.eq_ignore_ascii_case(m) {
        return Some(default.to_string());
    }
    None
}

/// Anthropic Messages 端点（F-39：+Anthropic 适配）
/// 请求：POST /v1/messages，鉴权支持 x-api-key 或 Authorization: Bearer
pub async fn messages(
    State(state): State<Arc<ApiSharedState>>,
    key_id: Option<Extension<KeyId>>,
    body: axum::body::Bytes,
) -> Response {
    if body.len() > MAX_BODY_BYTES {
        return anthropic_error(
            StatusCode::PAYLOAD_TOO_LARGE,
            "invalid_request_error",
            &body_too_large_msg(),
        );
    }

    state
        .total_requests
        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);

    // 校验 JSON 并预读 stream/model，再整体转为 OpenAI 内部格式复用现有链路
    let peek: Value = match serde_json::from_slice(&body) {
        Ok(v) => v,
        Err(e) => {
            return anthropic_error(
                StatusCode::BAD_REQUEST,
                "invalid_request_error",
                &format!("invalid JSON body: {}", e),
            )
        }
    };
    if peek.get("messages").and_then(|m| m.as_array()).is_none() {
        return anthropic_error(
            StatusCode::BAD_REQUEST,
            "invalid_request_error",
            "messages: field required",
        );
    }
    let stream = peek.get("stream").and_then(|v| v.as_bool()).unwrap_or(false);
    let mut model = peek
        .get("model")
        .and_then(|v| v.as_str())
        .filter(|s| !s.trim().is_empty())
        .unwrap_or(&state.default_model)
        .to_string();
    // issue #54 分类器模型兜底：改写原子生效——peek 插入与 body 重序列化任一步
    // 失败则整体跳过（model 变量与请求体模型名永不不一致），保证调度、outbound
    // 转换与白名单准入使用同一（可路由）模型名
    let mut peek = peek;
    let mut body = body;
    if let Some(rewritten) = anthropic_model_fallback(&state, &model) {
        let new_body = peek
            .as_object_mut()
            .map(|obj| {
                obj.insert("model".into(), serde_json::Value::String(rewritten.clone()));
            })
            .and_then(|_| serde_json::to_vec(&peek).ok())
            .map(axum::body::Bytes::from);
        if let Some(bytes) = new_body {
            crate::fs_utils::app_log(
                &state.data_dir,
                &format!(
                    "anthropic model fallback (issue #54): model={} -> {}",
                    model, rewritten
                ),
            );
            body = bytes;
            model = rewritten;
        }
    }
    // issue #26 白名单准入（空名单不限）
    if let Some(resp) = whitelist_check(&state, &model, Protocol::Anthropic) {
        return resp;
    }

    let body_vec = super::payload::anthropic_to_openai(&body);
    let state_clone = state.clone();
    let start_ts = std::time::Instant::now();
    let key_str = key_id.map(|Extension(k)| k.0).unwrap_or_else(|| "anonymous".to_string());

    // 统一调度分流点（§4.1）：resolve_target 决定资源池/回退/错误矩阵；
    // guard 随执行路径持有至请求结束（流式含整个后台任务）
    let guard = state.inflight_guard();
    match dispatch::resolve_target(&state, &model, &peek, Some(&key_str)) {
        Err(e) => dispatch_error_response(
            &state, e, Protocol::Anthropic, &model, stream, &key_str,
            start_ts.elapsed().as_millis() as u64,
        ),
        Ok(r) => match r.pool {
            TargetPool::Buddy => {
                // T5.3 默认深度思考：Anthropic 侧 thinking 参数视为显式请求
                let explicit = peek.get("thinking").map_or(false, |t| !t.is_null());
                let hint = effective_effort_hint(&state, r.effort_hint, explicit);
                let body_vec = apply_effort_hint(body_vec, hint);
                if stream {
                    return wb_route::wb_stream_chat(state_clone, body_vec, r.model, start_ts, Protocol::Anthropic, key_str, guard);
                }
                return wb_route::wb_aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::Anthropic, key_str, guard).await;
            }
            TargetPool::Qoder => {
                // Qoder 上游（p3-3）：Anthropic 入参已在端点层投影为 OpenAI 内部格式
                if stream {
                    return super::qoder_route::qoder_stream_chat(state_clone, body_vec, r.model, start_ts, Protocol::Anthropic, key_str, guard);
                }
                return super::qoder_route::qoder_aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::Anthropic, key_str, guard).await;
            }
            TargetPool::Trae => {
                // issue #31 T3.2/T3.3：Anthropic thinking 参数视为显式请求
                //（enabled → high 档；disabled → 空串短路默认思考与路由提示）
                let explicit = match peek.get("thinking") {
                    Some(t) if !t.is_null() => {
                        match t.get("type").and_then(|v| v.as_str()) {
                            Some("enabled") => Some("high".to_string()),
                            // 显式关闭（type=disabled 等已知关闭形态）：空串经
                            // trae_request_wire 短路 → 不下发
                            Some(_) => Some(String::new()),
                            // 缺 type（非合规形态，如仅 {"budget_tokens":N}）：对齐
                            // Buddy 侧「thinking 存在即显式开启」语义，判为开启
                            None => Some("high".to_string()),
                        }
                    }
                    _ => None,
                };
                let wire = trae_effort_wire(&state, r.effort_hint, explicit, &r.model);
                let body_vec = inject_trae_outbound(
                    &state.data_dir, body_vec, wire, r.max_mode_hint, &model, &r.model,
                );
                if stream {
                    stream_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::Anthropic, key_str, guard)
                } else {
                    aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::Anthropic, key_str, guard).await
                }
            }
            TargetPool::Custom => {
                match super::custom_models::find_enabled(&state.data_dir, &model) {
                    Some(cm) => {
                        if stream {
                            custom_route::custom_stream_chat(state_clone, body_vec, r.model, cm, start_ts, Protocol::Anthropic, key_str, guard)
                        } else {
                            custom_route::custom_aggregate_chat(state_clone, body_vec, r.model, cm, stream, start_ts, Protocol::Anthropic, key_str, guard).await
                        }
                    }
                    None => anthropic_error(StatusCode::NOT_FOUND, "model_not_found", &format!("自定义模型 {} 已被删除", model)),
                }
            }
        },
    }
}

/// OpenAI legacy text completions 端点（T9）
/// prompt（string 或 string[]）转单条 user message 复用现有链路，响应包装回
/// text_completion 结构。suffix/echo/logprobs/n 等参数不支持（忽略，上游单次补全）
pub async fn completions(
    State(state): State<Arc<ApiSharedState>>,
    key_id: Option<Extension<KeyId>>,
    body: axum::body::Bytes,
) -> Response {
    if body.len() > MAX_BODY_BYTES {
        return openai_error(
            StatusCode::PAYLOAD_TOO_LARGE,
            "request_too_large",
            &body_too_large_msg(),
        );
    }

    state
        .total_requests
        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);

    let peek: Value = match serde_json::from_slice(&body) {
        Ok(v) => v,
        Err(e) => {
            return openai_error(
                StatusCode::BAD_REQUEST,
                "invalid_request_error",
                &format!("invalid JSON body: {}", e),
            )
        }
    };
    let prompt_text = match peek.get("prompt") {
        Some(Value::String(s)) => s.clone(),
        // 多段 prompt：拼接为单个 prompt（上游一次只产出一个补全，无法返回多 choice）
        Some(Value::Array(arr)) => {
            let parts: Vec<String> = arr
                .iter()
                .filter_map(|v| v.as_str().map(str::to_string))
                .collect();
            if parts.is_empty() {
                return openai_error(
                    StatusCode::BAD_REQUEST,
                    "invalid_request_error",
                    "prompt: array must contain strings",
                );
            }
            parts.join("\n\n")
        }
        _ => {
            return openai_error(
                StatusCode::BAD_REQUEST,
                "invalid_request_error",
                "prompt: field required",
            )
        }
    };
    if prompt_text.trim().is_empty() {
        return openai_error(
            StatusCode::BAD_REQUEST,
            "invalid_request_error",
            "prompt: must not be empty",
        );
    }
    let stream = peek.get("stream").and_then(|v| v.as_bool()).unwrap_or(false);
    let model = peek
        .get("model")
        .and_then(|v| v.as_str())
        .filter(|s| !s.trim().is_empty())
        .unwrap_or(&state.default_model)
        .to_string();
    // issue #26 白名单准入（空名单不限）
    if let Some(resp) = whitelist_check(&state, &model, Protocol::OpenAiText) {
        return resp;
    }

    // prompt → user message，复用 /v1/chat/completions 内部链路
    let internal = json!({
        "model": model,
        "stream": stream,
        "messages": [{ "role": "user", "content": prompt_text }],
    });
    let body_vec = internal.to_string().into_bytes();

    let state_clone = state.clone();
    let start_ts = std::time::Instant::now();
    let key_str = key_id.map(|Extension(k)| k.0).unwrap_or_else(|| "anonymous".to_string());

    // 统一调度分流点（§4.1）；guard 随执行路径持有至请求结束
    let guard = state.inflight_guard();
    match dispatch::resolve_target(&state, &model, &internal, Some(&key_str)) {
        Err(e) => dispatch_error_response(
            &state, e, Protocol::OpenAiText, &model, stream, &key_str,
            start_ts.elapsed().as_millis() as u64,
        ),
        Ok(r) => match r.pool {
            TargetPool::Buddy => {
                // T5.3 默认深度思考（text completions 无 effort 字段 → 默认思考直接生效）
                let hint = effective_effort_hint(&state, r.effort_hint, false);
                let body_vec = apply_effort_hint(body_vec, hint);
                if stream {
                    return wb_route::wb_stream_chat(state_clone, body_vec, r.model, start_ts, Protocol::OpenAiText, key_str, guard);
                }
                return wb_route::wb_aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAiText, key_str, guard).await;
            }
            TargetPool::Qoder => {
                // Qoder 上游（p3-3）：text completions 入参已在端点层投影为内部格式
                if stream {
                    return super::qoder_route::qoder_stream_chat(state_clone, body_vec, r.model, start_ts, Protocol::OpenAiText, key_str, guard);
                }
                return super::qoder_route::qoder_aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAiText, key_str, guard).await;
            }
            TargetPool::Trae => {
                // issue #31 T3.2/T3.3：text completions 无 effort 字段 → 仅默认思考生效
                let wire = trae_effort_wire(&state, r.effort_hint, None, &r.model);
                let body_vec = inject_trae_outbound(
                    &state.data_dir, body_vec, wire, r.max_mode_hint, &model, &r.model,
                );
                if stream {
                    stream_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAiText, key_str, guard)
                } else {
                    aggregate_chat(state_clone, body_vec, r.model, stream, start_ts, Protocol::OpenAiText, key_str, guard).await
                }
            }
            TargetPool::Custom => {
                match super::custom_models::find_enabled(&state.data_dir, &model) {
                    Some(cm) => {
                        if stream {
                            custom_route::custom_stream_chat(state_clone, body_vec, r.model, cm, start_ts, Protocol::OpenAiText, key_str, guard)
                        } else {
                            custom_route::custom_aggregate_chat(state_clone, body_vec, r.model, cm, stream, start_ts, Protocol::OpenAiText, key_str, guard).await
                        }
                    }
                    None => openai_error(StatusCode::NOT_FOUND, "model_not_found", &format!("自定义模型 {} 已被删除", model)),
                }
            }
        },
    }
}

/// /v1/embeddings：上游 SOLO 无向量能力，明确返回 501（不做假实现）
pub async fn embeddings() -> Response {
    openai_error(
        StatusCode::NOT_IMPLEMENTED,
        "not_supported",
        "上游服务无 embeddings 能力，本网关不支持 /v1/embeddings，请使用 /v1/chat/completions 或 /v1/completions",
    )
}

/// /v1/images/generations 文生图（T5.4/F-63）：投影 WB 上游生图端点
pub async fn images_generations(
    State(state): State<Arc<ApiSharedState>>,
    key_id: Option<Extension<KeyId>>,
    body: axum::body::Bytes,
) -> Response {
    images_entry(state, key_id, body, false).await
}

/// /v1/images/edits 图生图（T5.4/F-63）：接受 JSON（image 为 base64/data URL）。
/// 注：OpenAI SDK 默认 multipart/form-data；本端点仅接受 JSON 变体（零新增依赖红线），
/// 客户端需将图像读为 base64 后以 JSON 提交。
pub async fn images_edits(
    State(state): State<Arc<ApiSharedState>>,
    key_id: Option<Extension<KeyId>>,
    body: axum::body::Bytes,
) -> Response {
    images_entry(state, key_id, body, true).await
}

async fn images_entry(
    state: Arc<ApiSharedState>,
    key_id: Option<Extension<KeyId>>,
    body: axum::body::Bytes,
    is_edit: bool,
) -> Response {
    state
        .total_requests
        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    // inflight guard（§4.5）：async fn 全程 inline await，作用域即请求生命周期
    let _guard = state.inflight_guard();
    if body.len() > MAX_BODY_BYTES {
        return openai_error(StatusCode::PAYLOAD_TOO_LARGE, "request_too_large", &body_too_large_msg());
    }
    let peek: Value = match serde_json::from_slice(&body) {
        Ok(v) => v,
        Err(e) => return openai_error(StatusCode::BAD_REQUEST, "invalid_request_error", &format!("invalid JSON body: {}", e)),
    };
    let model = peek
        .get("model")
        .and_then(|v| v.as_str())
        .filter(|s| !s.trim().is_empty())
        .unwrap_or("hy4")
        .to_string();
    // issue #26 白名单准入（空名单不限）
    if let Some(resp) = whitelist_check(&state, &model, Protocol::OpenAi) {
        return resp;
    }
    let prompt = peek.get("prompt").and_then(|v| v.as_str()).unwrap_or("").to_string();
    let image_b64 = peek.get("image").and_then(|v| v.as_str()).map(str::to_string);
    let key_str = key_id.map(|Extension(k)| k.0).unwrap_or_else(|| "anonymous".to_string());
    let start_ts = std::time::Instant::now();
    // 请求日志附带的 API Key 展示名（匿名/未知 → 空串，日志显示 "-"）
    let key_name = super::api_keys::key_name_for(&state.data_dir, &key_str);

    // 校验（目录命中 + 图片模态 + prompt/image 非空）
    let catalog = wb_catalog::load(&state.data_dir);
    if let Err((code, msg)) = super::wb_images::validate(
        &catalog,
        &model,
        &prompt,
        if is_edit { Some(image_b64.as_deref().unwrap_or("")) } else { None },
    ) {
        return openai_error(
            StatusCode::from_u16(code).unwrap_or(StatusCode::BAD_REQUEST),
            "invalid_request_error",
            &msg,
        );
    }

    // 取健康 WB 账号（生图无粘性语义，任一健康账号）；携带当前请求 Key 的
    // 约束（P1 修复4c）：白名单 allowed_accounts 过滤 + dedicated 专一锁定，
    // 与 wb_route 同款解析；Key 无约束/匿名（constraints_for 为 None）时不限制。
    // issue #25 资源池绑定：Key 绑定 trae 时约束作用域不在 WB 池（白名单空），
    // 生图仍用 WB 池但不应用 Trae 账号白名单（避免误过滤）。
    // issue #30 混合白名单：按前缀作用域提取 Buddy 条目（空集 = 排除，不得过滤）
    let (allowed_set, dedicated) = super::api_keys::constraints_for(&state.data_dir, &key_str)
        .and_then(|k| k.pool_constraints("buddy"))
        .map_or((None, None), |c| (c.allowed, c.dedicated));
    let picked = {
        let tried = HashSet::new();
        state
            .wb_pool
            .pick_excluding_constrained_ev(&tried, allowed_set.as_ref(), dedicated.as_deref())
            .map(|(p, ev)| {
                // F-77⑤ 可观测：busy_yield / busy_fallback 调度事件
                if let Some(ev) = ev {
                    state.logger.log_sched_event(&ev);
                }
                p
            })
    };
    let Some(picked) = picked else {
        return openai_error(StatusCode::SERVICE_UNAVAILABLE, "no_healthy_account", "no healthy WB account available");
    };
    let creds = super::wb_upstream::WbCreds {
        id: picked.uid.clone(),
        uid: picked.uid.clone(),
        name: String::new(),
        token: picked.jwt.clone(),
        domain: picked.domain.clone(),
        enterprise_id: picked.enterprise_id.clone(),
        global_region: picked.global_region,
    };

    let result = tokio::task::spawn_blocking(move || super::wb_images::generate(&creds, &peek))
        .await
        .unwrap_or_else(|e| Err((500u16, format!("task join error: {e}"))));
    let duration_ms = start_ts.elapsed().as_millis() as u64;
    match result {
        Ok(resp) => {
            // P1 修复4a：WB 账号服务的请求记 wb 桶（is_wb=true），与 Trae 侧分账
            state.record_usage(true, &model, &picked.uid, &key_str, true, false, duration_ms, 0, 0);
            state.wb_pool.note_success(&picked.uid);
            // P1 修复4b：上游池为 buddy，日志池归属同步纠正
            state.logger.log_request(
                "buddy", "POST",
                if is_edit { "/v1/images/edits" } else { "/v1/images/generations" },
                &model, false, 200, &picked.uid, duration_ms, &key_name,
                &state.wb_pool.name_of(&picked.uid), None,
            );
            Response::builder()
                .header("content-type", "application/json")
                .body(Body::from(resp.to_string()))
                .unwrap_or_else(|_| internal_error_response())
        }
        Err((code, msg)) => {
            state.record_usage(true, &model, &picked.uid, &key_str, false, false, duration_ms, 0, 0);
            state.logger.log_request(
                "buddy", "POST",
                if is_edit { "/v1/images/edits" } else { "/v1/images/generations" },
                &model, false, code, &picked.uid, duration_ms, &key_name,
                &state.wb_pool.name_of(&picked.uid), Some(&msg),
            );
            openai_error(
                StatusCode::from_u16(code).unwrap_or(StatusCode::BAD_GATEWAY),
                "upstream_error",
                &msg,
            )
        }
    }
}

// ==================== Streaming ====================

/// issue #25 资源池绑定：Key 绑定 trae 时 F-35 约束（白名单/专一）作用于 Trae 池；
/// 其余情况（未绑定旧语义/绑定 buddy/匿名）返回 (None, None) = 不限制。
/// F-35 旧语义兼容：未绑定 Key 的白名单历来只作用 WB 池，绝不能波及 Trae。
/// issue #30 混合白名单：带池前缀的未绑定 Key 按前缀作用域提取 Trae 条目
/// （零条目 = 空集排除）。pub(crate) 供 dispatch 测试模块复用 Fixture 覆盖四种作用域
pub(crate) fn trae_pool_constraints(
    state: &ApiSharedState,
    key_id: &str,
) -> (Option<HashSet<String>>, Option<String>) {
    super::api_keys::constraints_for(&state.data_dir, key_id)
        .and_then(|kc| kc.pool_constraints("trae"))
        .map_or((None, None), |c| (c.allowed, c.dedicated))
}

#[allow(clippy::too_many_arguments)]
fn stream_chat(state: Arc<ApiSharedState>, body_vec: Vec<u8>, model: String, stream: bool, start_ts: std::time::Instant, proto: Protocol, key_id: String, guard: InflightGuard) -> Response {
    let (tx, rx) = tokio::sync::mpsc::channel(64);

    // SSE keep-alive 15s（T2.7/F-34 §5.5 #7）：防中间层回收长流。
    // P1 修复：原 ticker 独占持有 sender 克隆，主任务发完 [DONE] 后流因
    // sender 未全部关闭而无法终结（普通 HTTP 客户端只能靠断连收尾）。
    // 改用 tokio::sync::watch：主任务结束（DoneSignal Drop）置 done=true，
    // ticker select! 收到退出信号即退出 → rx 关闭 → 流正常结束
    let (done_tx, mut done_rx) = tokio::sync::watch::channel(false);
    {
        let tx2 = tx.clone();
        tokio::spawn(async move {
            let mut tick = tokio::time::interval(std::time::Duration::from_secs(15));
            tick.tick().await; // 首个 tick 立即返回，跳过
            loop {
                tokio::select! {
                    _ = tick.tick() => {
                        if tx2
                            .send(Ok(bytes::Bytes::from(": keep-alive\n\n")))
                            .await
                            .is_err()
                        {
                            break;
                        }
                    }
                    // 主任务已结束：ticker 退出，放行流终结
                    _ = done_rx.changed() => break,
                }
            }
        });
    }

    // 批次 D-1 线程隔离：流任务迁入专用阻塞池，长流不再占用主 runtime 的
    // spawn_blocking 池（鉴权/短 IO 依赖它），防并发流耗尽池导致网关级联卡死。
    // Key 绑定 trae 的约束在闭包外解析（clone 进闭包，锁外取号）
    let (trae_allowed, trae_dedicated) = trae_pool_constraints(&state, &key_id);
    super::stream_runtime().spawn_blocking(move || {
        // inflight guard 随后台任务存续至流结束（§4.5：客户端断连/流终止由
        // 任务结束 Drop 兜底释放）；F-77 取号后绑定账号级计数
        let mut guard = guard;
        // 主任务结束（含 panic 展开）→ 通知 keep-alive ticker 退出（P1 修复3）
        let _done = DoneSignal(done_tx);
        // 请求日志附带的 API Key 展示名（匿名/未知 → 空串，日志显示 "-"）
        let key_name = super::api_keys::key_name_for(&state.data_dir, &key_id);
        let chat_id = match proto {
            Protocol::OpenAi => format!("chatcmpl-{}", now_ts()),
            Protocol::OpenAiText => format!("cmpl-{}", now_ts()),
            Protocol::Anthropic => format!("msg_{}", now_ts()),
            // Responses 仅走 WB 上游；solo 管线不会收到，兜底给 resp_ id
            Protocol::Responses => format!("resp_{}", now_ts()),
        };
        // 会话→账号粘性（per-pool 三参数批次，对齐 Buddy/Qoder）：显式
        // conversationId / 消息指纹命中且账号健康 → 首选粘住账号（上游 KV cache
        // 复用；busy 且有空闲候选时让位，F-77④ 同构）。子 Key 限定上游不含
        // 粘性账号时忽略粘性
        let peek: Value = serde_json::from_slice(&body_vec).unwrap_or_else(|_| json!({}));
        let sticky_key = SessionKey::from_body(&peek);
        // 空指纹（无 messages / 无 conversation_id）不可粘
        let sticky_usable = !sticky_key.cache_key().ends_with(':');
        let sticky0: Option<String> = if sticky_usable {
            state
                .trae_sticky
                .resolve(&sticky_key, now_ts() as i64)
                .and_then(|b| {
                    if trae_allowed.as_ref().is_some_and(|a| !a.contains(&b.uid)) {
                        return None;
                    }
                    state.pool.pick_by_uid(&b.uid).map(|_| b.uid)
                })
        } else {
            None
        };
        // 首选：粘性 > 调度策略；绑定回写用会话键占位 conv_id（Trae 上游无
        // 会话 id 复用语义，仅落库留档满足非空校验）
        let sticky_conv = sticky_key.cache_key();
        let mut first_pick: Option<super::pool::PickedAccount> = sticky0.as_ref().and_then(|u| {
            state
                .pool
                .pick_sticky_yield(u, trae_allowed.as_ref())
                .map(|(p, ev)| {
                    if let Some(ev) = ev {
                        state.logger.log_sched_event(&ev);
                    }
                    p
                })
        });
        let mut tried = HashSet::new();
        // 401 自愈去重（issue #27 方案 B）：每账号每请求最多强制刷新一次（对齐 wb_route T2.6）
        let mut refreshed_401 = HashSet::new();
        // 空完成计数（issue #57 后续可观测）：轮换耗尽收尾时区分「渠道指纹拦截」与「账号池耗尽」
        let mut empty_hits: usize = 0;
        // 指纹清洗（issue #57）：请求级快照（对齐 wb_route）——11128 强制开启后
        // 跨账号保持，换号不再以未清洗状态重烧一次拦截；热更新开关下请求生效
        let mut sanitize = state.wb_sanitize.load(std::sync::atomic::Ordering::Relaxed);
        let templates = super::wb_route::load_templates(&state);

        for _ in 0..MAX_ROTATE {
            // 客户端断连检测：通道关闭即终止轮换/重试，不再占用账号并发槽
            if tx.is_closed() {
                return;
            }
            // 取号：粘性命中优先（每请求仅首轮），否则按 Key 约束 + 调度策略；
            // 换号重试后仅走策略
            let mut picked = match first_pick.take() {
                Some(p) => p,
                None => match state
                    .pool
                    .pick_excluding_constrained(&tried, trae_allowed.as_ref(), trae_dedicated.as_deref())
                {
                    Some(p) => p,
                    None => break,
                },
            };
            tried.insert(picked.uid.clone());
            // F-77 账号级在途计数：取号即绑定（换号时 bind_account 自动解绑旧账号）。
            // 审查 P1-4 TOCTOU 收紧：普通候选 CAS 复核「在途 < 并发上限」，已满则
            // 不发起请求换下一候选（不计错误不冷却）；over_limit 候选（专一/粘性
            // 锁定、busy_fallback 降级）保留原无条件绑定语义
            let bound = if picked.over_limit {
                guard = guard.bind_account(state.pool.inflight_handle(&picked.uid));
                true
            } else {
                guard.bind_account_cas(
                    state.pool.inflight_handle(&picked.uid),
                    state.pool.concurrency_limit(),
                )
            };
            if !bound {
                continue;
            }
            *safe_lock(&state.active_uid) = Some(picked.uid.clone());

            let mut converted = super::payload::prepare_llm_chat_body(
                &body_vec, &state.default_model, &picked.uid, &picked.device_id, &picked.machine_id,
                // 模型目录（config_cache 缓存，热路径）：function 查表优先
                &super::models_sync::load_models(&state.data_dir),
                sanitize, &templates,
            );

            // 分级重试（T2.2/F-33，与 wb_route 同一张表）：same_attempt 为同账号
            // 重试计数，换号后随新账号归零；总轮换上限仍受 MAX_ROTATE 约束
            let mut same_attempt: u32 = 0;
            loop {
                // TTFB 计时（请求发起 → 上游首行到达，与 wb_route 同语义）：
                // AtomicU64 0 哨兵 = 尚未读到首行（首字超时等失败路径不产出 ttfb）
                let ttfb_start = std::time::Instant::now();
                let ttfb_us = std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0));
                match make_upstream_request(&picked.jwt, &picked.uid, &picked.device_id, &picked.machine_id, &converted) {
                    Ok((reader, primary_hdr)) => {
                        // 首字超时 10s（T2.7/F-34）+ F-76③ 慢请求竞速对冲（Trae 池，
                        // wb_route/qoder_route 同构）：首字节超阈值且有其他健康账号时
                        // 向第二账号发对冲请求，先出首字者胜；阈值 0 = 纯首字超时（原语义）。
                        // 双败/首字超时 → 冷却换号；首字节到达后正常流速不受限
                        let mut win = match race_trae_first_byte(
                            &state, &picked.uid, reader, primary_hdr, &tried, trae_allowed.as_ref(),
                            trae_dedicated.as_deref(), &body_vec, sanitize, &templates,
                        ) {
                            Ok(w) => w,
                            Err(()) => {
                                state.pool.note_error(&picked.uid, ErrKind::Server);
                                *safe_lock(&state.last_error) =
                                    Some(format!("uid={} first-byte timeout(10s)", picked.uid));
                                // P2 修复：失败尝试记账（与非流式/WB 口径一致）
                                state.record_usage(
                                    false, &model, &picked.uid, &key_id, false, stream,
                                    start_ts.elapsed().as_millis() as u64, 0, 0,
                                );
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    504, &picked.uid, start_ts.elapsed().as_millis() as u64,
                                    &key_name, &state.pool.name_of(&picked.uid),
                                    Some("first byte timeout"),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, None, 504, Some("first byte timeout"));
                                }
                                break; // 换号
                            }
                        };
                        // 对冲计数落定 + guard 重绑（接管时生效账号 = 对冲账号）；
                        // 后续记账/日志/粘性绑定均以生效账号 win_uid 为准
                        guard = settle_trae_hedge(&state, &mut win, guard, &picked.uid);
                        let TraeRaceWin { lines: win_lines, uid: win_uid, upstream_hdr, .. } = win;
                        // 首行打点包装：首次成功读到上游行即记录 ttfb（0 哨兵防重复
                        // 覆盖；叠加首字超时包装，语义为「请求发起 → 首行到达」）
                        let lines = {
                            let ttfb_flag = ttfb_us.clone();
                            win_lines.map(move |l| {
                                let _ = ttfb_flag.compare_exchange(
                                    0,
                                    ttfb_start.elapsed().as_micros() as u64,
                                    std::sync::atomic::Ordering::Relaxed,
                                    std::sync::atomic::Ordering::Relaxed,
                                );
                                l
                            })
                        };
                        // ttfb 包装产物为普通迭代器 → 桥接回可中断行源
                        // （转发线程复用；转换循环的停滞期断连轮询语义不变）
                        let lines = super::wb_upstream::InterruptibleLines::from_iterator(
                            Box::new(lines) as Box<dyn Iterator<Item = String> + Send>,
                        );
                        // 连接成功 → 开始流式转换，mid-stream error 只冷却不轮换
                        let (error_info, sent_any, up_usage) = match proto {
                            Protocol::OpenAi => {
                                let (e, s, u) = sse::stream_convert_lines(lines, tx.clone(), &chat_id);
                                (e, s, u)
                            }
                            Protocol::OpenAiText => {
                                let (e, s, u) =
                                    sse::stream_convert_text_lines(lines, tx.clone(), &chat_id, &model);
                                (e, s, u)
                            }
                            Protocol::Anthropic => {
                                let (e, s, u) =
                                    sse::stream_convert_anthropic_lines(lines, tx.clone(), &chat_id, &model);
                                (e, s, u)
                            }
                            // Responses 仅走 WB 上游；solo 管线兜底按 OpenAI 透传
                            Protocol::Responses => {
                                let (e, s, u) = sse::stream_convert_lines(lines, tx.clone(), &chat_id);
                                (e, s, u)
                            }
                        };
                        let duration_ms = start_ts.elapsed().as_millis() as u64;
                        // TTFB：首行到达耗时（未读到首行 → None，不输出该字段）
                        let ttfb_ms = {
                            let us = ttfb_us.load(std::sync::atomic::Ordering::Relaxed);
                            if us == 0 { None } else { Some(us / 1000) }
                        };
                        // 用量记账（流式结束即落盘；F-76① TTFT 入账；对冲接管记生效账号）
                        {
                            let (pt, ct) = up_usage.as_ref().map(extract_tokens).unwrap_or((0, 0));
                            state.record_usage_ttfb(
                                false, &model, &win_uid, &key_id, error_info.is_none(), true,
                                duration_ms, pt, ct, ttfb_ms,
                            );
                        }
                        if let Some((code, msg)) = error_info {
                            if super::is_empty_completion(code, &msg) {
                                // sent_any 护栏（对齐 qoder_route）：内容已流出时换号重发
                                // 会向同一 SSE 流拼接第二份完整响应 → 就地收尾不再重试
                                if sent_any {
                                    state.logger.log_request_ttfb(
                                        "trae", "POST", proto.log_path(), &model, stream,
                                        200, &win_uid, duration_ms, ttfb_ms, &key_name,
                                        &state.pool.name_of(&win_uid),
                                        Some(&format!(
                                            "空完成（内容已流出）→ 就地收尾 [upstream: {}]",
                                            upstream_hdr
                                        )),
                                    );
                                    return;
                                }
                                // 空完成（影子风控/上游异常，issue #57）：不冷却、不透传，
                                // 换号重试（收尾帧未发，重试流可在同一连接续传）
                                empty_hits += 1;
                                state.logger.log_request_ttfb(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    200, &win_uid, duration_ms, ttfb_ms, &key_name,
                                    &state.pool.name_of(&win_uid),
                                    Some(&format!(
                                        "空完成 → 换号重试{} [upstream: {}]",
                                        super::wb_payload::template_hit_note(),
                                        upstream_hdr
                                    )),
                                );
                                break; // 退出重试循环 → 换号
                            }
                            let kind = classify_solo_error(code, &msg);
                            if kind != ErrKind::None {
                                state.pool.note_error(&win_uid, kind);
                                *safe_lock(&state.last_error) =
                                    Some(format!("uid={} code={} msg={}", win_uid, code, msg));
                                // issue #67：硬冷却/禁用类错误解绑该账号粘性
                                if kind.unbinds_sticky() {
                                    state.trae_sticky.unbind_uid(&win_uid);
                                }
                            }
                            // issue #67：流未开始（零内容流出）的账号级错误 → 换号重试
                            // （对齐空完成分支：错误帧未下发，重试流可在同一连接续传；
                            // ErrKind::None 属请求级错误，换号无意义，照旧延迟透传）
                            if !sent_any && kind != ErrKind::None {
                                state.logger.log_request_ttfb(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    200, &win_uid, duration_ms, ttfb_ms, &key_name,
                                    &state.pool.name_of(&win_uid),
                                    Some(&format!("{} → 换号重试", msg)),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&win_uid, &converted, None, 200, Some(&msg));
                                }
                                break; // 退出重试循环 → 换号
                            }
                            if !sent_any {
                                // 流未开始：错误延迟下发（sse 层未透传，由这里统一发）
                                send_stream_error(&tx, proto, code, &msg);
                            }
                            state.logger.log_request_ttfb(
                                "trae", "POST", proto.log_path(), &model, stream,
                                200, &win_uid, duration_ms, ttfb_ms, &key_name,
                                &state.pool.name_of(&win_uid), Some(&msg),
                            );
                            if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                state.logger.log_debug(&win_uid, &converted, None, 200, Some(&msg));
                            }
                        } else {
                            state.pool.note_success(&win_uid);
                            // 绑定会话→账号粘性（仅 clean success；save 1s 节流；
                            // 对冲接管时绑定生效账号，会话后续粘住实际服务者）
                            if sticky_usable {
                                state.trae_sticky.bind(&sticky_key, &win_uid, &sticky_conv, now_ts() as i64);
                                state.trae_sticky.save(&state.data_dir);
                            }
                            state.logger.log_request_ttfb(
                                "trae", "POST", proto.log_path(), &model, stream,
                                200, &win_uid, duration_ms, ttfb_ms, &key_name,
                                &state.pool.name_of(&win_uid), None,
                            );
                            if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                state.logger.log_debug(&win_uid, &converted, None, 200, None);
                            }
                        }
                        return; // 流式结束后直接返回
                    }
                    Err((status, resp_body, retry_after)) => {
                        // 11128 渠道风控（issue #57）：按请求指纹拦截、与账号/模型无关，
                        // 换号无意义。清洗未启用时强制清洗后同号重试一次；已清洗仍命中
                        // → 走下方 retry_plan 原样 Fatal（需更新 wb_template_map.json）
                        if status == 400
                            && super::retry::is_illegal_channel_error(&resp_body)
                            && !sanitize
                        {
                            sanitize = true;
                            state.logger.log_sched_event(&format!(
                                "11128 强制清洗重试{}", super::wb_payload::template_hit_note()
                            ));
                            converted = super::payload::prepare_llm_chat_body(
                                &body_vec, &state.default_model, &picked.uid, &picked.device_id, &picked.machine_id,
                                &super::models_sync::load_models(&state.data_dir),
                                true, &templates,
                            );
                            std::thread::sleep(std::time::Duration::from_millis(200));
                            // 断连检测：重试等待期间客户端离开则终止
                            if tx.is_closed() {
                                return;
                            }
                            continue;
                        }
                        // 分级重试策略表（T2.2/F-33 v1.2，与 wb_route 保持一致）
                        match retry_plan(status, &resp_body, same_attempt, retry_after) {
                            RetryAction::RetrySame { delay_ms } => {
                                // 同账号重试：不 note_error 不冷却
                                same_attempt += 1;
                                std::thread::sleep(std::time::Duration::from_millis(delay_ms.min(60_000)));
                                // 断连检测：重试等待期间客户端离开则终止
                                if tx.is_closed() {
                                    return;
                                }
                                continue;
                            }
                            RetryAction::SwitchKey => {
                                // Trae 401 自愈（issue #27 方案 B，对齐 wb_route T2.6）：
                                // 强制刷新一次凭证后同号重试（每请求每账号一次）；成功则
                                // 不冷却不换号。失败/无回调维持原「note_error + 换号」语义。
                                if status == 401
                                    && !refreshed_401.contains(&picked.uid)
                                    && state.trae_jwt_refresh.is_some()
                                {
                                    refreshed_401.insert(picked.uid.clone());
                                    let refresh = state.trae_jwt_refresh.as_ref().unwrap();
                                    match refresh(&picked.uid) {
                                        Ok(new_jwt) => {
                                            let clean = new_jwt
                                                .strip_prefix("Cloud-IDE-JWT ")
                                                .unwrap_or(&new_jwt)
                                                .trim()
                                                .to_string();
                                            state.pool.update_jwt(&picked.uid, &clean);
                                            picked.jwt = clean;
                                            same_attempt += 1;
                                            continue; // 同号重试（新 JWT）
                                        }
                                        Err(e) => {
                                            state.logger.log_request(
                                                "trae", "POST", proto.log_path(), &model, stream,
                                                status, &picked.uid, start_ts.elapsed().as_millis() as u64,
                                                &key_name, &state.pool.name_of(&picked.uid),
                                                Some(&format!("401 自愈刷新失败: {}", e)),
                                            );
                                        }
                                    }
                                }
                                let kind = classify_error(status, &resp_body);
                                state.pool.note_error(&picked.uid, kind);
                                // issue #67：硬冷却/禁用类错误解绑该账号粘性
                                if kind.unbinds_sticky() {
                                    state.trae_sticky.unbind_uid(&picked.uid);
                                }
                                let preview = safe_slice(&resp_body, 200);
                                *safe_lock(&state.last_error) =
                                    Some(format!("uid={} status={} body={}", picked.uid, status, preview));
                                // P2 修复：失败尝试记账（与非流式/WB 口径一致）
                                state.record_usage(
                                    false, &model, &picked.uid, &key_id, false, stream,
                                    start_ts.elapsed().as_millis() as u64, 0, 0,
                                );
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    status, &picked.uid, start_ts.elapsed().as_millis() as u64,
                                    &key_name, &state.pool.name_of(&picked.uid),
                                    Some(&format!("upstream status={}", status)),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, Some(resp_body.as_bytes()), status, Some(&preview));
                                }
                                break; // 换号（same_attempt 随新账号归零）
                            }
                            RetryAction::Fatal => {
                                // 不冷却：请求本身问题（换号无意义），终止并透传上游错误体
                                let msg = format!("upstream {} error: {}", status, safe_slice(&resp_body, 300));
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    status, &picked.uid, start_ts.elapsed().as_millis() as u64,
                                    &key_name, &state.pool.name_of(&picked.uid),
                                    Some(&msg),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, Some(resp_body.as_bytes()), status, Some(&msg));
                                }
                                send_stream_error(&tx, proto, status as i64, &msg);
                                return;
                            }
                        }
                    }
                }
            }
        }

        // 所有账号不可用（空完成主导 → 明示渠道指纹拦截语义，否则维持原文案）
        let duration_ms = start_ts.elapsed().as_millis() as u64;
        state.record_usage(false, &model, "none", &key_id, false, true, duration_ms, 0, 0);
        let (healthy_total, _) = state.pool.selectable_stats_in(None);
        let (exhaust_msg, exhaust_tag) = exhaust_message(empty_hits, tried.len(), healthy_total);
        let diag = state.pool.diagnose();
        let diag_summary: Vec<String> = diag
            .iter()
            .map(|d| {
                let credits_str = d.credits.map(|c| format!("{:.0}", c)).unwrap_or_else(|| "N/A".to_string());
                let cd_str = if d.until > 0 { format!(",cd={}s", d.until.saturating_sub(now_ts() as i64)) } else { String::new() };
                let exp_str = d.credits_expire_at.filter(|&e| e > 0).map(|e| format!(",exp={}", e)).unwrap_or_default();
                let dis_str = if d.disabled { ",DIS" } else { "" };
                format!("{}({}:{},cr={}{}{}{})", d.name, d.uid.get(..8).unwrap_or(&d.uid), d.reason, credits_str, cd_str, exp_str, dis_str)
            })
            .collect();
        state.logger.log_request(
            "trae", "POST", proto.log_path(), &model, stream,
            503, "none", duration_ms, &key_name, "",
            Some(&exhaust_msg),
        );
        // 写入 app.log 供排查
        {
            let now = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs();
            let local_ts = now + 8 * 3600;
            let h = (local_ts % 86400) / 3600;
            let m = (local_ts % 3600) / 60;
            let s = local_ts % 60;
            let diag_line = format!(
                "{exhaust_tag} [{:02}:{:02}:{:02}] tried={} empty_hits={} pool={} reasons=[{}]",
                h, m, s, tried.len(), empty_hits, diag.len(), diag_summary.join(", "),
            );
            state.logger.log_debug_line(format!("[DEBUG] {diag_line}"));
        }
        match proto {
            Protocol::OpenAi | Protocol::OpenAiText => {
                let err_body = json!({
                    "error": {"message": exhaust_msg, "type": "api_error", "code": "no_healthy_account"}
                });
                let _ = tx.blocking_send(Ok(bytes::Bytes::from(format!(
                    "data: {}\n\n",
                    err_body
                ))));
                let _ = tx.blocking_send(Ok(bytes::Bytes::from("data: [DONE]\n\n")));
            }
            Protocol::Anthropic => {
                let err = json!({
                    "type": "error",
                    "error": {
                        "type": "api_error",
                        "message": exhaust_msg,
                    },
                });
                let _ = tx.blocking_send(Ok(bytes::Bytes::from(format!(
                    "event: error\ndata: {}\n\n",
                    err
                ))));
            }
            Protocol::Responses => {
                let body = json!({
                    "type": "response.failed",
                    "response": {
                        "id": format!("resp_{}", now_ts()),
                        "object": "response",
                        "status": "failed",
                        "output": [],
                        "error": {"code": "no_healthy_account", "message": exhaust_msg},
                    },
                });
                let _ = tx.blocking_send(Ok(bytes::Bytes::from(format!(
                    "event: response.failed\ndata: {}\n\n",
                    body
                ))));
            }
        }
    });

    let stream = ReceiverStream::new(rx);
    Response::builder()
        .header("content-type", "text/event-stream")
        .header("cache-control", "no-cache")
        .header("connection", "keep-alive")
        .body(Body::from_stream(stream))
        .unwrap_or_else(|_| {
            Response::builder()
                .status(StatusCode::INTERNAL_SERVER_ERROR)
                .body(Body::from("internal server error"))
                .unwrap()
        })
}

// ==================== Non-streaming ====================

async fn aggregate_chat(state: Arc<ApiSharedState>, body_vec: Vec<u8>, model: String, stream: bool, start_ts: std::time::Instant, proto: Protocol, key_id: String, guard: InflightGuard) -> Response {
    // P2 修复：聚合含分级重试（RetrySame 退避 std::thread::sleep 最长 60s×N），
    // 长阻塞占主池会饿死鉴权等短任务，迁入 stream_runtime 专用阻塞池。
    // Key 绑定 trae 的约束在闭包外解析（clone 进闭包，锁外取号）
    let (trae_allowed, trae_dedicated) = trae_pool_constraints(&state, &key_id);
    let result = super::stream_runtime().spawn_blocking(move || {
        // inflight guard 随后台任务存续至聚合完成（§4.5）；F-77 取号后绑定账号级计数
        let mut guard = guard;
        // 请求日志附带的 API Key 展示名（匿名/未知 → 空串，日志显示 "-"）
        let key_name = super::api_keys::key_name_for(&state.data_dir, &key_id);
        // 会话→账号粘性（per-pool 三参数批次，与流式路径同构）：显式
        // conversationId / 消息指纹命中且账号健康 → 首选粘住账号；子 Key 限定
        // 上游不含粘性账号时忽略粘性
        let peek: Value = serde_json::from_slice(&body_vec).unwrap_or_else(|_| json!({}));
        let sticky_key = SessionKey::from_body(&peek);
        // 空指纹（无 messages / 无 conversation_id）不可粘
        let sticky_usable = !sticky_key.cache_key().ends_with(':');
        let sticky0: Option<String> = if sticky_usable {
            state
                .trae_sticky
                .resolve(&sticky_key, now_ts() as i64)
                .and_then(|b| {
                    if trae_allowed.as_ref().is_some_and(|a| !a.contains(&b.uid)) {
                        return None;
                    }
                    state.pool.pick_by_uid(&b.uid).map(|_| b.uid)
                })
        } else {
            None
        };
        // 首选：粘性 > 调度策略；绑定回写用会话键占位 conv_id（仅落库留档）
        let sticky_conv = sticky_key.cache_key();
        let mut first_pick: Option<super::pool::PickedAccount> = sticky0.as_ref().and_then(|u| {
            state
                .pool
                .pick_sticky_yield(u, trae_allowed.as_ref())
                .map(|(p, ev)| {
                    if let Some(ev) = ev {
                        state.logger.log_sched_event(&ev);
                    }
                    p
                })
        });
        let mut tried = HashSet::new();
        // 401 自愈去重（issue #27 方案 B）：每账号每请求最多强制刷新一次（对齐 wb_route T2.6）
        let mut refreshed_401 = HashSet::new();
        // 空完成计数（issue #57 后续可观测）：轮换耗尽收尾时区分「渠道指纹拦截」与「账号池耗尽」
        let mut empty_hits: usize = 0;
        // 指纹清洗（issue #57）：请求级快照（对齐 wb_route）——11128 强制开启后
        // 跨账号保持，换号不再以未清洗状态重烧一次拦截；热更新开关下请求生效
        let mut sanitize = state.wb_sanitize.load(std::sync::atomic::Ordering::Relaxed);
        let templates = super::wb_route::load_templates(&state);

        for _ in 0..MAX_ROTATE {
            // 取号：粘性命中优先（每请求仅首轮），否则按 Key 约束 + 调度策略；
            // 换号重试后仅走策略
            let mut picked = match first_pick.take() {
                Some(p) => p,
                None => match state
                    .pool
                    .pick_excluding_constrained(&tried, trae_allowed.as_ref(), trae_dedicated.as_deref())
                {
                    Some(p) => p,
                    None => break,
                },
            };
            tried.insert(picked.uid.clone());
            // F-77 账号级在途计数：取号即绑定（换号时自动解绑旧账号）。
            // 审查 P1-4 TOCTOU 收紧：普通候选 CAS 复核「在途 < 并发上限」，已满则
            // 不发起请求换下一候选（不计错误不冷却）；over_limit 候选（专一/粘性
            // 锁定、busy_fallback 降级）保留原无条件绑定语义。
            // active_uid 仅在绑定成功后更新（CAS 拒绝的候选不得污染「当前账号」展示）
            let bound = if picked.over_limit {
                guard = guard.bind_account(state.pool.inflight_handle(&picked.uid));
                true
            } else {
                guard.bind_account_cas(
                    state.pool.inflight_handle(&picked.uid),
                    state.pool.concurrency_limit(),
                )
            };
            if !bound {
                continue;
            }
            *safe_lock(&state.active_uid) = Some(picked.uid.clone());

            let mut converted = super::payload::prepare_llm_chat_body(
                &body_vec, &state.default_model, &picked.uid, &picked.device_id, &picked.machine_id,
                // 模型目录（config_cache 缓存，热路径）：function 查表优先
                &super::models_sync::load_models(&state.data_dir),
                sanitize, &templates,
            );

            // 分级重试（T2.2/F-33，与 wb_route 同一张表）：same_attempt 为同账号
            // 重试计数，换号后随新账号归零；总轮换上限仍受 MAX_ROTATE 约束
            let mut same_attempt: u32 = 0;
            loop {
                match make_upstream_request(&picked.jwt, &picked.uid, &picked.device_id, &picked.machine_id, &converted) {
                    Ok((reader, primary_hdr)) => {
                        let chat_id = match proto {
                            Protocol::OpenAi => format!("chatcmpl-{}", now_ts()),
                            Protocol::OpenAiText => format!("cmpl-{}", now_ts()),
                            Protocol::Anthropic => format!("msg_{}", now_ts()),
                            Protocol::Responses => format!("resp_{}", now_ts()),
                        };
                        let (resp, error_info) = match proto {
                            Protocol::OpenAi => sse::aggregate(reader, &chat_id),
                            Protocol::OpenAiText => sse::aggregate_text(reader, &chat_id, &model),
                            Protocol::Anthropic => sse::aggregate_anthropic(reader, &chat_id, &model),
                            // Responses 仅走 WB 上游；solo 管线兜底按 OpenAI 聚合
                            Protocol::Responses => sse::aggregate(reader, &chat_id),
                        };
                        let duration_ms = start_ts.elapsed().as_millis() as u64;
                        match (resp, error_info) {
                            (Some(r), None) => {
                                if super::aggregated_response_is_empty(&r) {
                                    // 空完成（影子风控/上游异常，issue #57）：换号重试，
                                    // 口径同下方「empty response」（Server 级短冷却）
                                    empty_hits += 1;
                                    state.pool.note_error(&picked.uid, ErrKind::Server);
                                    state.record_usage(
                                        false, &model, &picked.uid, &key_id, false, stream,
                                        duration_ms, 0, 0,
                                    );
                                    state.logger.log_request(
                                        "trae", "POST", proto.log_path(), &model, stream,
                                        502, &picked.uid, duration_ms, &key_name,
                                        &state.pool.name_of(&picked.uid),
                                        Some(&format!(
                                            "空完成 → 换号重试{} [upstream: {}]",
                                            super::wb_payload::template_hit_note(),
                                            primary_hdr
                                        )),
                                    );
                                    break; // 换号
                                }
                                // 用量记账（成功：token 数从聚合响应 usage 提取）
                                let (pt, ct) = r.get("usage").map(extract_tokens).unwrap_or((0, 0));
                                state.record_usage(
                                    false, &model, &picked.uid, &key_id, true, stream,
                                    duration_ms, pt, ct,
                                );
                                state.pool.note_success(&picked.uid);
                                // 绑定会话→账号粘性（仅 clean success；save 1s 节流）
                                if sticky_usable {
                                    state.trae_sticky.bind(&sticky_key, &picked.uid, &sticky_conv, now_ts() as i64);
                                    state.trae_sticky.save(&state.data_dir);
                                }
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    200, &picked.uid, duration_ms, &key_name,
                                    &state.pool.name_of(&picked.uid), None,
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, Some(r.to_string().as_bytes()), 200, None);
                                }
                                return Ok(r);
                            }
                            (None, Some((code, msg))) => {
                                // 空完成哨兵（-9901，影子风控）计入指纹拦截观测；
                                // 冷却行为维持现状（classify_solo_error → Server）
                                if super::is_empty_completion(code, &msg) {
                                    empty_hits += 1;
                                }
                                let kind = classify_solo_error(code, &msg);
                                // 请求级错误（ErrKind::None）不计账号错误——与流式路径
                                // 守卫一致；误计会在连续 3 次后熔断健康账号
                                if kind != ErrKind::None {
                                    state.pool.note_error(&picked.uid, kind);
                                    // issue #67：硬冷却/禁用类错误解绑该账号粘性
                                    if kind.unbinds_sticky() {
                                        state.trae_sticky.unbind_uid(&picked.uid);
                                    }
                                }
                                *safe_lock(&state.last_error) = Some(format!(
                                    "uid={} code={} msg={}",
                                    picked.uid,
                                    code,
                                    safe_slice(&msg, 300)
                                ));
                                state.record_usage(
                                    false, &model, &picked.uid, &key_id, false, stream,
                                    duration_ms, 0, 0,
                                );
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    200, &picked.uid, duration_ms, &key_name,
                                    &state.pool.name_of(&picked.uid), Some(&msg),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, None, 200, Some(&msg));
                                }
                                if kind == ErrKind::None {
                                    // issue #38-2/T5：请求级错误（4001 param invalid /
                                    // model config mismatch）与账号无关——换任何账号都会
                                    // 复现同类错误，轮换只会打满整池后报 503（issue 实测
                                    // 双账号被连打）。终止轮换，按 400 透传上游错误
                                    //（不记 note_error，账号健康度不受影响）
                                    return Err(AggregateFail::Upstream(
                                        400,
                                        format!("upstream code={} msg={}", code, safe_slice(&msg, 300)),
                                    ));
                                }
                                break; // 账号级错误：冷却换号
                            }
                            _ => {
                                state.pool.note_error(&picked.uid, ErrKind::Server);
                                state.record_usage(
                                    false, &model, &picked.uid, &key_id, false, stream,
                                    duration_ms, 0, 0,
                                );
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    502, &picked.uid, duration_ms, &key_name,
                                    &state.pool.name_of(&picked.uid), Some("empty response"),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, None, 502, Some("empty response"));
                                }
                                break; // 换号
                            }
                        }
                    }
                    Err((status, resp_body, retry_after)) => {
                        // 11128 渠道风控（issue #57）：清洗未启用时强制清洗后同号重试一次；
                        // 已清洗仍命中 → 走下方 retry_plan 原样 Fatal
                        if status == 400
                            && super::retry::is_illegal_channel_error(&resp_body)
                            && !sanitize
                        {
                            sanitize = true;
                            state.logger.log_sched_event(&format!(
                                "11128 强制清洗重试{}", super::wb_payload::template_hit_note()
                            ));
                            converted = super::payload::prepare_llm_chat_body(
                                &body_vec, &state.default_model, &picked.uid, &picked.device_id, &picked.machine_id,
                                &super::models_sync::load_models(&state.data_dir),
                                true, &templates,
                            );
                            std::thread::sleep(std::time::Duration::from_millis(200));
                            continue;
                        }
                        // 分级重试策略表（T2.2/F-33 v1.2，与 wb_route 保持一致）
                        match retry_plan(status, &resp_body, same_attempt, retry_after) {
                            RetryAction::RetrySame { delay_ms } => {
                                // 同账号重试：不 note_error 不冷却
                                same_attempt += 1;
                                std::thread::sleep(std::time::Duration::from_millis(delay_ms.min(60_000)));
                                continue;
                            }
                            RetryAction::SwitchKey => {
                                // Trae 401 自愈（issue #27 方案 B，对齐 wb_route T2.6）：
                                // 强制刷新一次凭证后同号重试（每请求每账号一次）；成功则
                                // 不冷却不换号。失败/无回调维持原「note_error + 换号」语义。
                                if status == 401
                                    && !refreshed_401.contains(&picked.uid)
                                    && state.trae_jwt_refresh.is_some()
                                {
                                    refreshed_401.insert(picked.uid.clone());
                                    let refresh = state.trae_jwt_refresh.as_ref().unwrap();
                                    match refresh(&picked.uid) {
                                        Ok(new_jwt) => {
                                            let clean = new_jwt
                                                .strip_prefix("Cloud-IDE-JWT ")
                                                .unwrap_or(&new_jwt)
                                                .trim()
                                                .to_string();
                                            state.pool.update_jwt(&picked.uid, &clean);
                                            picked.jwt = clean;
                                            same_attempt += 1;
                                            continue; // 同号重试（新 JWT）
                                        }
                                        Err(e) => {
                                            state.logger.log_request(
                                                "trae", "POST", proto.log_path(), &model, stream,
                                                status, &picked.uid, start_ts.elapsed().as_millis() as u64,
                                                &key_name, &state.pool.name_of(&picked.uid),
                                                Some(&format!("401 自愈刷新失败: {}", e)),
                                            );
                                        }
                                    }
                                }
                                let kind = classify_error(status, &resp_body);
                                state.pool.note_error(&picked.uid, kind);
                                // issue #67：硬冷却/禁用类错误解绑该账号粘性
                                if kind.unbinds_sticky() {
                                    state.trae_sticky.unbind_uid(&picked.uid);
                                }
                                *safe_lock(&state.last_error) =
                                    Some(format!("uid={} status={}", picked.uid, status));
                                state.record_usage(
                                    false, &model, &picked.uid, &key_id, false, stream,
                                    start_ts.elapsed().as_millis() as u64, 0, 0,
                                );
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    status, &picked.uid, start_ts.elapsed().as_millis() as u64,
                                    &key_name, &state.pool.name_of(&picked.uid),
                                    Some(&format!("upstream status={}", status)),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, Some(resp_body.as_bytes()), status, Some(&resp_body));
                                }
                                break; // 换号（same_attempt 随新账号归零）
                            }
                            RetryAction::Fatal => {
                                // 不冷却：请求本身问题（换号无意义），终止并透传上游错误体
                                let msg = format!("upstream {} error: {}", status, safe_slice(&resp_body, 300));
                                state.logger.log_request(
                                    "trae", "POST", proto.log_path(), &model, stream,
                                    status, &picked.uid, start_ts.elapsed().as_millis() as u64,
                                    &key_name, &state.pool.name_of(&picked.uid),
                                    Some(&msg),
                                );
                                if state.debug_enabled.load(std::sync::atomic::Ordering::Relaxed) {
                                    state.logger.log_debug(&picked.uid, &converted, Some(resp_body.as_bytes()), status, Some(&msg));
                                }
                                return Err(AggregateFail::Upstream(status, msg));
                            }
                        }
                    }
                }
            }
        }

        let duration_ms = start_ts.elapsed().as_millis() as u64;
        // 轮换耗尽收尾：空完成主导 → 明示渠道指纹拦截语义，否则维持原文案
        let (healthy_total, _) = state.pool.selectable_stats_in(None);
        let (exhaust_msg, exhaust_tag) = exhaust_message(empty_hits, tried.len(), healthy_total);
        let diag = state.pool.diagnose();
        // 用量记账（所有账号不可用）
        state.record_usage(false, &model, "none", &key_id, false, stream, duration_ms, 0, 0);
        let diag_summary: Vec<String> = diag
            .iter()
            .map(|d| {
                let credits_str = d.credits.map(|c| format!("{:.0}", c)).unwrap_or_else(|| "N/A".to_string());
                let cd_str = if d.until > 0 { format!(",cd={}s", d.until.saturating_sub(now_ts() as i64)) } else { String::new() };
                let exp_str = d.credits_expire_at.filter(|&e| e > 0).map(|e| format!(",exp={}", e)).unwrap_or_default();
                let dis_str = if d.disabled { ",DIS" } else { "" };
                format!("{}({}:{},cr={}{}{}{})", d.name, d.uid.get(..8).unwrap_or(&d.uid), d.reason, credits_str, cd_str, exp_str, dis_str)
            })
            .collect();
        state.logger.log_request(
            "trae", "POST", proto.log_path(), &model, stream,
            503, "none", duration_ms, &key_name, "",
            Some(&exhaust_msg),
        );
        // 写入诊断日志
        {
            state.logger.log_debug_line(format!(
                "[DEBUG] {exhaust_tag}(non-stream) tried={} empty_hits={} pool={} reasons=[{}]",
                tried.len(), empty_hits, diag.len(), diag_summary.join(", "),
            ));
        }
        Err(AggregateFail::NoHealthy(exhaust_msg))
    })
    .await;

    match result {
        Ok(Ok(resp)) => Response::builder()
            .header("content-type", "application/json")
            .body(Body::from(resp.to_string()))
            .unwrap_or_else(|_| {
                Response::builder()
                    .status(StatusCode::INTERNAL_SERVER_ERROR)
                    .body(Body::from("internal server error"))
                    .unwrap()
            }),
        Ok(Err(AggregateFail::NoHealthy(msg))) => match proto {
            Protocol::OpenAi | Protocol::OpenAiText | Protocol::Responses => {
                openai_error(StatusCode::SERVICE_UNAVAILABLE, "no_healthy_account", &msg)
            }
            Protocol::Anthropic => anthropic_error(StatusCode::SERVICE_UNAVAILABLE, "api_error", &msg),
        },
        Ok(Err(AggregateFail::Upstream(status, msg))) => {
            // Fatal：上游错误体透传（不冷却），按协议格式化并保留上游状态码
            let sc = StatusCode::from_u16(status).unwrap_or(StatusCode::BAD_GATEWAY);
            match proto {
                Protocol::Anthropic => anthropic_error(sc, "api_error", &msg),
                _ => openai_error(sc, "upstream_error", &msg),
            }
        }
        Err(e) => openai_error(
            StatusCode::INTERNAL_SERVER_ERROR,
            "internal_error",
            &format!("task join error: {}", e),
        ),
    }
}

// ==================== F-76③ 慢请求竞速对冲（Trae 池，wb_route/qoder_route 同构） ====================

/// 对冲账号在途计数租约（镜像 wb_route::HedgeLease，P0 泄漏修复）：
/// 构造即 +1（竞速窗口占用），Drop 即 -1——建连失败（闭包内 `?` 提前返回）、
/// 双败（`lines_with_first_byte_hedged` Err 路径内 Drop）、竞速胜出（随
/// `RaceOutcome.hedge` 移交调用方，`settle_trae_hedge` 落定后 Drop）三类
/// 退出路径均恰好释放一次，杜绝计数泄漏导致的账号永久 busy
struct TraeHedgeLease {
    uid: String,
    counter: Arc<std::sync::atomic::AtomicU32>,
    /// 对冲请求的上游响应头摘要（空 = 建连后未捕获）；对冲接管时用于空完成取证
    upstream_hdr: String,
}

impl TraeHedgeLease {
    fn acquire(state: &ApiSharedState, uid: &str) -> Self {
        let counter = state.pool.inflight_handle(uid);
        counter.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        Self { uid: uid.to_string(), counter, upstream_hdr: String::new() }
    }
}

impl Drop for TraeHedgeLease {
    fn drop(&mut self) {
        self.counter.fetch_sub(1, std::sync::atomic::Ordering::Relaxed);
    }
}

/// 首字竞速胜者信息（镜像 wb_route::RaceWin）：生效账号 + 对冲计数租约
struct TraeRaceWin {
    lines: Box<dyn Iterator<Item = String> + Send>,
    /// 生效账号 uid（对冲接管时为对冲账号）
    uid: String,
    /// 对冲侧计数租约（None = 未触发对冲；Some = 竞速已定，待 settle 释放）
    hedge: Option<TraeHedgeLease>,
    /// 对冲接管（对冲请求先出首字）
    takeover: bool,
    /// 生效请求的上游响应头摘要：主请求胜出 → 主请求摘要；对冲接管 → 对冲侧
    /// 摘要（未捕获时降级保留主请求摘要）。空完成日志取证用
    upstream_hdr: String,
}

/// 首字竞速（Trae 池，镜像 wb_route::race_first_byte）：对冲关闭（阈值 0）
/// 时与纯首字超时语义完全一致；开启时主请求首字节超阈值 → 从池内取第二账号
/// （走同一 busy 过滤/负载因子——主账号已 inflight 天然让位）发对冲请求，
/// 先出首字者胜。对冲请求体按对冲账号指纹重建（device/machine id 逐账号
/// 注入，不能复用主请求体）
#[allow(clippy::too_many_arguments)]
fn race_trae_first_byte(
    state: &Arc<ApiSharedState>,
    primary_uid: &str,
    reader: Box<dyn Read + Send>,
    primary_hdr: String,
    tried: &HashSet<String>,
    allowed: Option<&HashSet<String>>,
    dedicated: Option<&str>,
    body_vec: &[u8],
    sanitize: bool,
    templates: &[(String, String)],
) -> Result<TraeRaceWin, ()> {
    let hedge_ms = state
        .trae_hedge_threshold_ms
        .load(std::sync::atomic::Ordering::Relaxed);
    if hedge_ms == 0 {
        let lines = super::wb_upstream::lines_with_first_byte_timeout(reader)?;
        return Ok(TraeRaceWin {
            lines,
            uid: primary_uid.to_string(),
            hedge: None,
            takeover: false,
            upstream_hdr: primary_hdr,
        });
    }
    let state2 = state.clone();
    let tried2 = tried.clone();
    let allowed2 = allowed.cloned();
    let dedicated2 = dedicated.map(str::to_string);
    let body = body_vec.to_vec();
    let templates2 = templates.to_vec();
    let spawn_backup = move || -> Option<(Box<dyn Read + Send>, TraeHedgeLease)> {
        let (picked2, ev) = state2
            .pool
            .pick_excluding_constrained_ev(&tried2, allowed2.as_ref(), dedicated2.as_deref())?;
        // F-77⑤ 可观测：对冲取号同样记录 busy 让位/降级事件
        if let Some(ev) = ev {
            state2.logger.log_sched_event(&ev);
        }
        // 租约先于建连获取：建连失败（下行 `?`）时随闭包局部变量 Drop 自动 -1
        let mut lease = TraeHedgeLease::acquire(&state2, &picked2.uid);
        // 对冲请求体按对冲账号指纹重建
        let converted2 = super::payload::prepare_llm_chat_body(
            &body,
            &state2.default_model,
            &picked2.uid,
            &picked2.device_id,
            &picked2.machine_id,
            &super::models_sync::load_models(&state2.data_dir),
            sanitize,
            &templates2,
        );
        let (reader2, hdr2) = make_upstream_request(
            &picked2.jwt,
            &picked2.uid,
            &picked2.device_id,
            &picked2.machine_id,
            &converted2,
        )
        .ok()?;
        lease.upstream_hdr = hdr2;
        Some((reader2, lease))
    };
    match super::wb_upstream::lines_with_first_byte_hedged(reader, hedge_ms, spawn_backup) {
        Ok(out) => {
            let uid = if out.takeover {
                out.hedge
                    .as_ref()
                    .map(|l| l.uid.clone())
                    .unwrap_or_else(|| primary_uid.to_string())
            } else {
                primary_uid.to_string()
            };
            // 生效侧响应头摘要：主请求胜出 → 主请求摘要；对冲接管 → 对冲侧摘要
            //（对冲侧未捕获到时降级保留主请求摘要，仍可凭主请求凭据追溯/申诉）
            let mut upstream_hdr = primary_hdr;
            if out.takeover {
                if let Some(l) = out.hedge.as_ref() {
                    if !l.upstream_hdr.is_empty() {
                        upstream_hdr = l.upstream_hdr.clone();
                    }
                }
            }
            Ok(TraeRaceWin {
                lines: out.lines,
                uid,
                hedge: out.hedge,
                takeover: out.takeover,
                upstream_hdr,
            })
        }
        Err(()) => Err(()),
    }
}

/// 竞速结束后处理对冲计数与日志（镜像 wb_route::settle_hedge）：
/// 释放对冲账号竞速窗口占用；接管时 guard 重绑到对冲账号；[SCHED] 日志记录
/// hedge_takeover / hedge_lost
fn settle_trae_hedge(
    state: &ApiSharedState,
    win: &mut TraeRaceWin,
    mut guard: InflightGuard,
    primary_uid: &str,
) -> InflightGuard {
    let Some(lease) = win.hedge.take() else {
        return guard;
    };
    let hedge_uid = lease.uid.as_str();
    if win.takeover {
        state
            .logger
            .log_sched_event(&format!("hedge_takeover primary={} hedge={}", primary_uid, hedge_uid));
        guard = guard.bind_account(lease.counter.clone());
    } else {
        state
            .logger
            .log_sched_event(&format!("hedge_lost primary={} hedge={}", primary_uid, hedge_uid));
    }
    drop(lease); // 释放竞速窗口占用（接管路径先重绑流计数再释放，语义与原实现一致）
    guard
}

// ==================== Upstream Request ====================

/// 上游错误体读取上限（P2 修复11）：防止上游异常回包把整响应读进内存
const MAX_UPSTREAM_ERR_BYTES: usize = 64 * 1024;

/// 限量读取上游错误体（P2 修复11）：最多 MAX_UPSTREAM_ERR_BYTES，读满截断
fn read_limited_body(response: ureq::Response) -> String {
    let mut buf = Vec::new();
    let mut limited = response
        .into_reader()
        .take(MAX_UPSTREAM_ERR_BYTES as u64);
    let _ = limited.read_to_end(&mut buf);
    String::from_utf8_lossy(&buf).into_owned()
}

/// 空完成取证（issue #57）：上游 HTTP 200 零内容时，把响应侧可追溯标识
/// （logid / 网关请求 id / trace 类头）与我方发出的 trace/request-id 拼成一行
/// 紧凑摘要，追加进空完成日志，为向上游申诉或自查提供凭据。
/// 仅收录存在的头；值按字符截断到 96 防日志膨胀。
fn upstream_header_digest(r: &ureq::Response, sent_trace: &str, sent_req_id: &str) -> String {
    const CANDIDATES: [&str; 7] = [
        "logid",
        "x-tt-logid",
        "x-lgw-request-id",
        "x-lgw-trace-id",
        "x-request-id",
        "x-tt-envflags",
        "server-timing",
    ];
    let mut parts: Vec<String> = Vec::new();
    for name in CANDIDATES {
        if let Some(v) = r.header(name) {
            let v = v.trim();
            if !v.is_empty() {
                parts.push(format!("{}={}", name, v.chars().take(96).collect::<String>()));
            }
        }
    }
    parts.push(format!("sent_trace={}", sent_trace));
    parts.push(format!("sent_req={}", sent_req_id));
    parts.join("; ")
}

fn make_upstream_request(
    jwt: &str,
    _uid: &str,
    device_id: &str,
    machine_id: &str,
    body: &[u8],
) -> Result<(Box<dyn Read + Send>, String), (u16, String, Option<u64>)> {
    let url = format!("{}{}", AGENT_HOST, EP_LLM_CHAT);
    let referer = format!("{}{}", REFERER_BASE, EP_LLM_CHAT);
    let trace_id = format!(
        "00-{}-{}-01",
        uuid_like_id(),
        uuid_like_id()
    );
    let request_id = format!("req_{}", uuid_like_id());

    let resp = streaming_agent()
        .post(&url)
        .set("content-type", "application/json")
        .set("accept", "*/*")
        .set("accept-encoding", "gzip, deflate, br, zstd")
        .set("user-agent", "TraeClient/TTNet")
        .set("x-ide-token", jwt)
        .set("x-app-id", APP_ID)
        .set("x-app-version", "default")
        .set("x-app-version-code", IDE_VERSION_CODE)
        .set("x-ide-version", IDE_VERSION)
        .set("x-ide-version-code", IDE_VERSION_CODE)
        .set("x-ide-version-type", "stable")
        .set("x-device-type", "windows")
        .set("x-device-brand", "CREFG-XX")
        .set("x-device-cpu", "Intel")
        .set("x-device-id", device_id)
        .set("x-machine-id", machine_id)
        .set("x-os-version", "Windows 11 Home China")
        .set("request-traffic-type", "prod")
        .set("package-type", "stable_cn")
        .set("x-lgw-req-sdk-type", "3")
        .set("x-lscbd-aid", "787976")
        .set("x-lscbd-platform", "windows")
        .set("x-ss-dp", "787976")
        .set("app-version", IDE_VERSION)
        .set("x-custom-trace-id", &trace_id[..16])
        .set("x-flow-traceparent", &format!("04-{}-{}-01", &trace_id[3..35], uuid_like_id()))
        .set("x-tt-trace-id", &trace_id)
        .set("x-request-id", &request_id)
        .set("referer", &referer)
        .send_bytes(body);

    match resp {
        Ok(r) => {
            // 空完成取证：必须在 into_reader 消费响应前捕获响应头（与下方
            // retry-after 同一约束）；摘要随 reader 一并返回
            let digest = upstream_header_digest(&r, &trace_id[..16], &request_id);
            Ok((Box::new(r.into_reader()), digest))
        }
        Err(ureq::Error::Status(code, response)) => {
            // Retry-After（秒）解析（P1 修复1）：供分级重试表 429 退避决策；
            // header 需在 into_reader 消费响应前读取
            let retry_after = response
                .header("retry-after")
                .and_then(|v| v.trim().parse::<u64>().ok());
            let body = read_limited_body(response);
            Err((code, body, retry_after))
        }
        Err(e) => {
            let err_str = format!("{}", e);
            // 区分 DNS 解析失败 / 连接超时 / TLS 错误，提供更精准的诊断
            let detail = if err_str.contains("dns") || err_str.contains("resolve") || err_str.contains("name resolution") {
                format!("DNS解析失败（{} 无法解析），请检查网络或代理设置: {}", AGENT_HOST, e)
            } else if err_str.contains("timed out") || err_str.contains("timeout") {
                format!("连接超时（{} 10秒内未响应），请检查网络连通性: {}", AGENT_HOST, e)
            } else if err_str.contains("tls") || err_str.contains("certificate") || err_str.contains("ssl") {
                format!("TLS证书验证失败: {}", e)
            } else {
                format!("传输错误: {}", e)
            };
            Err((502, detail, None))
        }
    }
}

// ==================== Helpers ====================

/// 空 message 兜底（issue #71）：上游错误体可能提取不到 message（如本地代理
/// 劫持 127.0.0.1 回环流量后返回的空体），透传空串会让客户端只看到
/// {"message":""}，缺乏诊断价值；统一回填含状态码的提示文案
pub(crate) fn msg_or_fallback(msg: &str, status: u16) -> Cow<'_, str> {
    if !msg.trim().is_empty() {
        return Cow::Borrowed(msg);
    }
    Cow::Owned(format!(
        "上游服务返回 {status} 但未提供错误详情：常见于网络波动、上游服务异常，或本地全局代理（Clash 等）劫持 127.0.0.1 回环流量；请检查网络与代理设置，详见应用运行日志"
    ))
}

/// 流式错误 message 兜底（issue #71）：code 可能是 HTTP 状态码也可能是业务码
/// （如 6004，或缺失时兜底的 0）；非 HTTP 语义时不冒充状态码，文案与
/// error.code 字段保持一致，避免客户端按 message 误判上游状态
pub(crate) fn stream_msg_or_fallback(msg: &str, code: i64) -> Cow<'_, str> {
    if !msg.trim().is_empty() {
        return Cow::Borrowed(msg);
    }
    if (100..=599).contains(&code) {
        return msg_or_fallback(msg, code as u16);
    }
    Cow::Owned(format!(
        "上游返回错误码 {code} 但未提供错误详情：常见于网络波动、上游服务异常，或本地全局代理（Clash 等）劫持 127.0.0.1 回环流量；请检查网络与代理设置，详见应用运行日志"
    ))
}

/// OpenAI 错误响应格式（wb_route 复用）
pub(crate) fn openai_error(status: StatusCode, code: &str, msg: &str) -> Response {
    let msg = msg_or_fallback(msg, status.as_u16());
    let body = json!({
        "error": {
            "message": msg,
            "type": "api_error",
            "code": code,
        }
    });
    Response::builder()
        .status(status)
        .header("content-type", "application/json")
        .body(Body::from(body.to_string()))
        .unwrap_or_else(|_| {
            Response::builder()
                .status(StatusCode::INTERNAL_SERVER_ERROR)
                .body(Body::from("{\"error\":{\"message\":\"internal error\"}}"))
                .unwrap()
        })
}

/// Anthropic 错误响应格式：{"type":"error","error":{"type","message"}}（wb_route 复用）
pub(crate) fn anthropic_error(status: StatusCode, err_type: &str, msg: &str) -> Response {
    let msg = msg_or_fallback(msg, status.as_u16());
    let body = json!({
        "type": "error",
        "error": {
            "type": err_type,
            "message": msg,
        }
    });
    Response::builder()
        .status(status)
        .header("content-type", "application/json")
        .body(Body::from(body.to_string()))
        .unwrap_or_else(|_| {
            Response::builder()
                .status(StatusCode::INTERNAL_SERVER_ERROR)
                .body(Body::from("{\"type\":\"error\",\"error\":{\"type\":\"api_error\",\"message\":\"internal error\"}}"))
                .unwrap()
        })
}

/// 流式错误统一下发：sse 层在流未开始时不透传错误（留待重试决策），
/// 由此处按客户端协议格式化错误事件并收尾
pub(crate) fn send_stream_error(
    tx: &tokio::sync::mpsc::Sender<Result<bytes::Bytes, std::io::Error>>,
    proto: Protocol,
    code: i64,
    msg: &str,
) {
    let msg = stream_msg_or_fallback(msg, code);
    match proto {
        Protocol::OpenAi | Protocol::OpenAiText => {
            let body = json!({
                "error": { "message": msg, "type": "api_error", "code": code }
            });
            let _ = tx.blocking_send(Ok(bytes::Bytes::from(format!("data: {}\n\n", body))));
            let _ = tx.blocking_send(Ok(bytes::Bytes::from("data: [DONE]\n\n")));
        }
        Protocol::Anthropic => {
            let err = json!({
                "type": "error",
                "error": { "type": "api_error", "message": msg },
            });
            let _ = tx.blocking_send(Ok(bytes::Bytes::from(format!(
                "event: error\ndata: {}\n\n",
                err
            ))));
        }
        Protocol::Responses => {
            let body = json!({
                "type": "response.failed",
                "response": {
                    "id": format!("resp_{}", now_ts()),
                    "object": "response",
                    "status": "failed",
                    "output": [],
                    "error": {"code": code.to_string(), "message": msg},
                },
            });
            let _ = tx.blocking_send(Ok(bytes::Bytes::from(format!(
                "event: response.failed\ndata: {}\n\n",
                body
            ))));
        }
    }
}

fn now_ts() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

/// 生成类似 UUID 的十六进制字符串，用于 trace-id 等请求头
fn uuid_like_id() -> String {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default();
    let nanos = now.as_nanos();
    let seed = (nanos as u64).wrapping_mul(0x517cc1b727220a95);
    let mut buf = [0u8; 16];
    buf[0..8].copy_from_slice(&seed.to_le_bytes());
    buf[8..16].copy_from_slice(&(seed.wrapping_add(0x9e3779b97f4a7c15)).to_le_bytes());
    buf.iter().map(|b| format!("{:02x}", b)).collect()
}

fn safe_slice(s: &str, n: usize) -> &str {
    // P2 修复6：沿字符边界向前找 <=n 的最大可截断点。原实现非字符边界时
    // 回退返回整串（可能超长），且字节切片 &s[..n] 在多字节字符中间会 panic
    // （上游错误 JSON 常含中文）；现保证输出永不超过 n 字节且不 panic
    if n >= s.len() {
        return s;
    }
    let mut cut = 0;
    for (i, _) in s.char_indices().take_while(|(i, _)| *i <= n) {
        cut = i;
    }
    &s[..cut]
}

#[cfg(test)]
mod tests {
    use super::*;

    // ==================== 空 message 兜底（issue #71） ====================

    #[test]
    fn msg_or_fallback_keeps_non_empty_message() {
        assert_eq!(
            msg_or_fallback("upstream code=6004 msg=限额", 502),
            "upstream code=6004 msg=限额"
        );
        assert_eq!(msg_or_fallback("  x  ", 500), "  x  ");
    }

    #[test]
    fn msg_or_fallback_backfills_blank_message_with_status_hint() {
        for blank in ["", " ", "\n\t"] {
            let m = msg_or_fallback(blank, 502);
            assert!(m.contains("502"), "{m}");
            assert!(m.contains("127.0.0.1"), "{m}");
        }
    }

    #[test]
    fn stream_msg_or_fallback_maps_http_and_business_codes() {
        // HTTP 语义 code（含边界 100/599）：沿用状态码文案，与 code 字段一致
        for code in [100_i64, 404, 502, 599] {
            let m = stream_msg_or_fallback("", code);
            assert!(m.contains("上游服务返回"), "code={code}: {m}");
            assert!(m.contains(&code.to_string()), "code={code}: {m}");
        }
        // 业务码/缺失（0）/越界（99、600）/负数/超大 i64：按错误码提示，不冒充状态码
        for code in [0_i64, 99, 600, 6004, -9901, i64::MAX] {
            let m = stream_msg_or_fallback("", code);
            assert!(m.contains("错误码"), "code={code}: {m}");
            assert!(m.contains(&code.to_string()), "code={code}: {m}");
        }
        // 非空 msg 一律原样透传（不 trim 保留原文）
        assert_eq!(stream_msg_or_fallback("  x  ", 6004), "  x  ");
    }

    // ==================== 轮换耗尽收尾文案：指纹拦截 vs 账号池耗尽 ====================

    #[test]
    fn exhaust_message_empty_hits_indicates_fingerprint_block() {
        // 空完成主导：明示指纹拦截语义（账号/模型无关），带清洗规则表提示与健康计数
        let (msg, tag) = exhaust_message(3, 3, 4);
        assert!(msg.contains("channel fingerprint block suspected"), "{msg}");
        assert!(msg.contains("3 empty completion(s) across 3 rotated accounts"), "{msg}");
        assert!(msg.contains("healthy=4"), "{msg}");
        assert!(msg.contains("wb_template_map.json"), "{msg}");
        assert_eq!(tag, "CHANNEL_FINGERPRINT_BLOCK");
    }

    #[test]
    fn exhaust_message_no_empty_hits_keeps_original() {
        // 无空完成（401/429/5xx 等真实不健康）：维持原文案，避免误导
        let (msg, tag) = exhaust_message(0, 3, 0);
        assert_eq!(msg, "no healthy account available");
        assert_eq!(tag, "NO_HEALTHY_ACCOUNT");
    }

    #[test]
    fn exhaust_message_minority_empty_hits_keeps_original() {
        // 混合失败：仅 1 次空完成 + 其余限流/5xx，空完成非主导 → 不宣判指纹拦截，
        // 避免 "switching won't help" 误导排障方向（限流等待冷却即可自愈）
        let (msg, tag) = exhaust_message(1, 10, 2);
        assert_eq!(msg, "no healthy account available");
        assert_eq!(tag, "NO_HEALTHY_ACCOUNT");
    }

    #[test]
    fn exhaust_message_majority_empty_hits_indicates_fingerprint_block() {
        // 过半轮换账号返回空完成（6/10）→ 判定指纹拦截主导
        let (msg, tag) = exhaust_message(6, 10, 2);
        assert!(msg.contains("channel fingerprint block suspected"), "{msg}");
        assert_eq!(tag, "CHANNEL_FINGERPRINT_BLOCK");
    }

    // ==================== P2 修复6：safe_slice 字符边界截断 ====================

    #[test]
    fn safe_slice_cuts_on_char_boundary() {
        // ASCII：n 在串内 → 精确截断
        assert_eq!(safe_slice("hello world", 5), "hello");
        // n 超长 → 原文
        assert_eq!(safe_slice("abc", 100), "abc");
        // n 等于串长 → 原文
        assert_eq!(safe_slice("abc", 3), "abc");
        // n=0 → 空串（原实现会 panic）
        assert_eq!(safe_slice("中文", 0), "");
    }

    #[test]
    fn safe_slice_never_returns_overlong_or_panics() {
        // 200 落在多字节字符中间：沿边界向前取最近可截断点，不 panic、不回退整串
        let s = format!("{}{}", "a".repeat(199), "中文中文中文");
        let out = safe_slice(&s, 200);
        assert!(out.len() <= 200, "输出不得超过 n 字节");
        assert_eq!(out.len(), 199, "应回退到最近字符边界（199 处）");
        // n=1/2 落在 3 字节「中」的中间 → 边界回退到 0
        assert_eq!(safe_slice("中文", 1), "");
        assert_eq!(safe_slice("中文", 2), "");
        assert_eq!(safe_slice("中文", 3), "中");
        // 任意 n 都不 panic 且不超长
        let body = "上游错误：{\"code\":1005,\"message\":\"套餐额度用尽\"}";
        for n in 0..=body.len() {
            let out = safe_slice(body, n);
            assert!(out.len() <= n);
            assert!(body.starts_with(out));
        }
    }

    // ==================== issue #26 全局模型白名单 ====================

    /// 白名单准入用的最小 state fixture：仅 data_dir 参与白名单读取（kv SQLite），
    /// 其余字段与 dispatch 测试 fixture 同构（空池/默认开关）；Drop 兜底清理临时目录
    struct WlFixture {
        dir: std::path::PathBuf,
        state: Arc<ApiSharedState>,
    }

    impl Drop for WlFixture {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.dir);
        }
    }

    fn wl_fixture(tag: &str) -> WlFixture {
        let dir = std::env::temp_dir().join(format!(
            "twa_routes_wl_test_{}_{}_{}",
            std::process::id(),
            tag,
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_nanos()
        ));
        std::fs::create_dir_all(&dir).unwrap();
        let state = Arc::new(ApiSharedState {
            pool: super::super::pool::ApiPool::new(),
            wb_pool: super::super::pool::ApiPool::new(),
            wb_enabled: std::sync::atomic::AtomicBool::new(true),
            wb_sanitize: std::sync::atomic::AtomicBool::new(true),
            wb_default_thinking: std::sync::atomic::AtomicBool::new(false),
            wb_tool_exec: std::sync::atomic::AtomicBool::new(false),
            wb_bg_downgrade: std::sync::atomic::AtomicBool::new(false),
            wb_longctx_downgrade: std::sync::atomic::AtomicBool::new(false),
            wb_hedge_threshold_ms: std::sync::atomic::AtomicU64::new(0),
            trae_hedge_threshold_ms: std::sync::atomic::AtomicU64::new(0),
            trae_pool_sticky_ttl_secs: std::sync::atomic::AtomicU64::new(300),
            wb_pool_sticky_ttl_secs: std::sync::atomic::AtomicU64::new(300),
            qoder_pool_sticky_ttl_secs: std::sync::atomic::AtomicU64::new(300),
            wb_sticky: super::super::wb_sticky::StickyStore::default(),
            model_cooldowns: std::sync::Mutex::new(std::collections::HashMap::new()),
            default_model: "deepseek-v4-flash".into(),
            data_dir: dir.clone(),
            total_requests: std::sync::atomic::AtomicU64::new(0),
            inflight: std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0)),
            active_uid: std::sync::Mutex::new(None),
            last_error: std::sync::Mutex::new(None),
            pool_sticky: std::sync::Mutex::new(std::collections::HashMap::new()),
            logger: super::super::ApiLogger::new(dir.join("logs")),
            debug_enabled: std::sync::atomic::AtomicBool::new(false),
            usage: std::sync::Mutex::new(super::super::usage::UsageFile::default()),
            usage_dirty: std::sync::Mutex::new(Vec::new()),
            wb_probe_ts_ms: std::sync::atomic::AtomicI64::new(-1),
            wb_probe_ok: std::sync::atomic::AtomicI64::new(-1),
            trae_jwt_refresh: None,
            trae_enabled: std::sync::atomic::AtomicBool::new(true),
            qoder_pool: super::super::pool::ApiPool::new(),
            qoder_enabled: std::sync::atomic::AtomicBool::new(true),
            qoder_identity: None,
            qoder_hedge_threshold_ms: std::sync::atomic::AtomicU64::new(0),
            qoder_sticky_enabled: std::sync::atomic::AtomicBool::new(false),
            qoder_sticky: super::super::wb_sticky::StickyStore::default(),
            trae_sticky: super::super::wb_sticky::StickyStore::default(),
            listen_host: std::sync::Mutex::new("127.0.0.1".to_string()),
        });
        WlFixture { dir, state }
    }

    /// 拒绝壳格式（纯函数）：OpenAI 三协议共用 model_not_found 404 壳，
    /// Anthropic 用 not_found_error；消息携带模型名与 /v1/models 指引
    #[tokio::test]
    async fn whitelist_error_response_format_by_protocol() {
        for proto in [Protocol::OpenAi, Protocol::OpenAiText, Protocol::Responses] {
            let resp = whitelist_error_response("kimi-k3", proto);
            assert_eq!(resp.status(), StatusCode::NOT_FOUND, "{}", proto.log_path());
            let bytes = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
            let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
            assert_eq!(v["error"]["code"], "model_not_found");
            assert_eq!(v["error"]["type"], "api_error");
            let msg = v["error"]["message"].as_str().unwrap();
            assert!(msg.contains("kimi-k3") && msg.contains("/v1/models"), "{}", msg);
        }
        // Anthropic：type=error 外壳 + not_found_error
        let resp = whitelist_error_response("kimi-k3", Protocol::Anthropic);
        assert_eq!(resp.status(), StatusCode::NOT_FOUND);
        let bytes = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(v["type"], "error");
        assert_eq!(v["error"]["type"], "not_found_error");
        assert!(v["error"]["message"].as_str().unwrap().contains("kimi-k3"));
    }

    /// whitelist_check 端到端（真实 kv 读写）：空名单放行；canonical 归一命中；
    /// 非名单模型返回按协议格式化的 404
    #[tokio::test]
    async fn whitelist_check_state_end_to_end() {
        let f = wl_fixture("e2e");
        // 空名单 = 不限（默认行为零变化）
        assert!(whitelist_check(&f.state, "glm-5.3", Protocol::OpenAi).is_none());
        // 保存「GLM-5.3」→ 大小写/空白变体均命中（canonical 归一）
        unified_catalog::save_whitelist(&f.dir, &["GLM-5.3".to_string()]).unwrap();
        assert!(whitelist_check(&f.state, "GLM-5.3", Protocol::OpenAi).is_none());
        assert!(whitelist_check(&f.state, "  glm-5.3 ", Protocol::Anthropic).is_none());
        // 非名单模型 → 404 model_not_found（OpenAI 壳）
        let denied = whitelist_check(&f.state, "kimi-k3", Protocol::OpenAi).unwrap();
        assert_eq!(denied.status(), StatusCode::NOT_FOUND);
        let bytes = axum::body::to_bytes(denied.into_body(), usize::MAX).await.unwrap();
        let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(v["error"]["code"], "model_not_found");
    }

    /// 审查 C1 + issue #90 修复③a：池前缀模型按裸名准入（与 /v1/models 别名
    /// 条目同一前缀语义）；被拒时拒绝信息保留用户请求的原始名（含前缀），
    /// 不得显示裸名（遮蔽回归防护）
    #[tokio::test]
    async fn whitelist_check_prefix_admission_keeps_original_name_in_denial() {
        let f = wl_fixture("prefix");
        unified_catalog::save_whitelist(&f.dir, &["glm-5.3".to_string()]).unwrap();
        // 前缀模型按裸名准入
        assert!(whitelist_check(&f.state, "trae/glm-5.3", Protocol::OpenAi).is_none());
        // 非名单前缀模型 → 404 且消息保留原始前缀名
        let denied = whitelist_check(&f.state, "trae/kimi-k3", Protocol::OpenAi).unwrap();
        assert_eq!(denied.status(), StatusCode::NOT_FOUND);
        let bytes = axum::body::to_bytes(denied.into_body(), usize::MAX).await.unwrap();
        let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        let msg = v["error"]["message"].as_str().unwrap();
        assert!(
            msg.contains("model trae/kimi-k3 is not in"),
            "拒绝信息应保留原始前缀名: {msg}"
        );
    }

    // ==================== issue #54：Claude Code 分类器模型兜底 ====================

    /// `[1m]` 窗口标记剥离：仅尾部完整标记生效，剥离后非空
    #[test]
    fn strip_bracket_1m_tail_only() {
        assert_eq!(strip_bracket_1m("claude-sonnet-5[1m]"), Some("claude-sonnet-5"));
        assert_eq!(strip_bracket_1m("glm-5.3[1M]"), Some("glm-5.3"));
        assert_eq!(strip_bracket_1m("claude-sonnet-5[1m]x"), None, "非尾部标记不剥");
        assert_eq!(strip_bracket_1m("[1m]"), None, "剥离后为空不剥");
        assert_eq!(strip_bracket_1m("claude-sonnet-5"), None);
    }

    /// 多字节字符 + 大小写字节长度变化：字节尾比较不 panic、不切错位置。
    /// `ẞ`(U+1E9E,3B)→`ß`(2B)、`İ`(2B)→`i̇`(3B) 均会漂移 to_lowercase 偏移，
    /// 旧实现（lower 偏移切原串）在 `claude-ẞ[1m]` 上越过字符边界直接 panic
    #[test]
    fn strip_bracket_1m_multibyte_case_folding_safe() {
        assert_eq!(strip_bracket_1m("claude-ẞ[1m]"), Some("claude-ẞ"));
        assert_eq!(strip_bracket_1m("glm-5.3İ[1M]"), Some("glm-5.3İ"));
        // 多字节结尾/中部标记不误判
        assert_eq!(strip_bracket_1m("中文模型"), None);
        assert_eq!(strip_bracket_1m("模型[1m]中"), None);
        // 4 字节以内短输入不 panic
        assert_eq!(strip_bracket_1m("[1"), None);
        assert_eq!(strip_bracket_1m(""), None);
    }

    /// 纯 Trae 用户（WB 关闭）：分类器官方模型名三池不可路由 → 回落网关默认模型
    #[tokio::test]
    async fn fallback_claude_classifier_to_default_when_unroutable() {
        let f = wl_fixture("claude_fb");
        f.state
            .wb_enabled
            .store(false, std::sync::atomic::Ordering::Relaxed);
        // 分类器 side_query 的官方模型名（issue #54 报错模型）
        assert_eq!(
            anthropic_model_fallback(&f.state, "claude-sonnet-5[1m]").as_deref(),
            Some("deepseek-v4-flash")
        );
        // 无窗口标记的 claude 系未知名同样兜底
        assert_eq!(
            anthropic_model_fallback(&f.state, "Claude-Opus-5").as_deref(),
            Some("deepseek-v4-flash")
        );
    }

    /// WB 启用用户：claude-* 经内置系列映射命中 WB 目录 → 原样保留（行为不变）
    #[tokio::test]
    async fn fallback_keeps_claude_when_wb_routes_it() {
        let f = wl_fixture("claude_wb"); // fixture 默认 wb_enabled=true，builtin 目录含 glm-5.3
        assert!(anthropic_model_fallback(&f.state, "claude-sonnet-5[1m]").is_none());
    }

    /// 基名在目录（原名带 [1m] 不在）→ 剥标记用基名
    #[tokio::test]
    async fn fallback_strips_1m_when_base_routable() {
        let f = wl_fixture("claude_1m");
        assert_eq!(
            anthropic_model_fallback(&f.state, "glm-5.3[1M]").as_deref(),
            Some("glm-5.3")
        );
    }

    /// 非 claude 未知名维持透传语义（与 dispatch t07 零行为差异）；默认模型同名不循环改写
    #[tokio::test]
    async fn fallback_leaves_unknown_names_passthrough() {
        let f = wl_fixture("claude_pass");
        f.state
            .wb_enabled
            .store(false, std::sync::atomic::Ordering::Relaxed);
        assert!(anthropic_model_fallback(&f.state, "brand-new-model").is_none());
        // 未知名带 [1m] 但基名不可路由且非 claude 系 → 原样
        assert!(anthropic_model_fallback(&f.state, "brand-new-model[1m]").is_none());
        // 模型名恰为默认模型 → None（不产生无意义改写）
        assert!(anthropic_model_fallback(&f.state, "deepseek-v4-flash").is_none());
    }

    // ==================== issue #31 T3.2/T3.3：Trae effort wire ====================

    /// 三源合成：显式请求 > 路由提示 > 默认思考；空串显式 = Anthropic thinking
    /// disabled 编码，短路为 None（同时压制默认思考与路由提示）；实证表外模型
    /// 显式请求按统一→Trae 映射填充默认下发（合成默认不下发）；canonical 归一
    /// 命中实证表
    #[test]
    fn trae_effort_wire_three_sources_and_short_circuit() {
        let f = wl_fixture("effort");

        // 无显式、无提示、默认思考关 → None
        assert!(trae_effort_wire(&f.state, None, None, "glm-5.3").is_none());

        // 路由提示兜底（实证表内模型 → wire 命中）
        assert_eq!(
            trae_effort_wire(&f.state, Some("high".into()), None, "glm-5.3").as_deref(),
            Some("high")
        );

        // 显式优先于路由提示；统一档位映射：low → light
        assert_eq!(
            trae_effort_wire(&f.state, Some("high".into()), Some("low".into()), "glm-5.3")
                .as_deref(),
            Some("light")
        );

        // 统一档位映射：xhigh → extra_high
        assert_eq!(
            trae_effort_wire(&f.state, None, Some("xhigh".into()), "glm-5.3").as_deref(),
            Some("extra_high")
        );

        // 默认思考开 → high（仍经实证表转换）
        f.state
            .wb_default_thinking
            .store(true, std::sync::atomic::Ordering::Relaxed);
        assert_eq!(
            trae_effort_wire(&f.state, None, None, "glm-5.3").as_deref(),
            Some("high")
        );

        // 显式关闭（空串编码）短路一切：默认思考开着、路由提示在也返回 None
        assert!(
            trae_effort_wire(&f.state, Some("high".into()), Some(String::new()), "glm-5.3")
                .is_none()
        );

        // 实证表外模型（Trae 无实证，如档位仅 Buddy 侧声明）：显式请求填充默认
        //（统一→Trae 映射直接下发）；合成默认（路由提示）不下发
        assert_eq!(
            trae_effort_wire(&f.state, None, Some("high".into()), "deepseek-v4-flash").as_deref(),
            Some("high")
        );
        assert_eq!(
            trae_effort_wire(&f.state, None, Some("medium".into()), "deepseek-v4-flash")
                .as_deref(),
            Some("light")
        );
        assert!(trae_effort_wire(&f.state, Some("high".into()), None, "deepseek-v4-flash").is_none());

        // canonical 归一：大小写变体同样命中实证表
        assert_eq!(
            trae_effort_wire(&f.state, None, Some("high".into()), "GLM-5.3").as_deref(),
            Some("high")
        );
    }

    /// Trae 出站注入（issue #31 T3.3/T4.2，合并后单次 parse）：effort wire=Some 写
    /// reasoning_effort_level（T0.2 抓包后仅改 TRAE_EFFORT_FIELD 常量）；Max Mode
    /// 入口标志 + 支持表双门控、未请求不注入（保持请求最小化）、注入值布尔 true；
    /// body model 字段回写剥离后基名（issue #38 真机根因）；原字段保留；三路均未
    /// 激活原样返回；非对象/非 JSON body 原样返回
    #[test]
    fn inject_trae_outbound_variants() {
        // 测试桩：注入函数现需 data_dir 落可观测性日志（issue #38-5），指向临时目录
        let dir = std::env::temp_dir();
        let inject = |body: Vec<u8>, wire: Option<String>, mm: bool, requested: &str, model: &str| {
            inject_trae_outbound(&dir, body, wire, mm, requested, model)
        };
        let body = br#"{"model":"glm-5.3","messages":[]}"#.to_vec();

        // 三路均未激活 → 原样（零 parse）
        assert_eq!(inject(body.clone(), None, false, "glm-5.3", "glm-5.3"), body);

        // effort 单路：注入字段，原字段保留
        let out = inject(body.clone(), Some("extra_high".into()), false, "glm-5.3", "glm-5.3");
        let v: serde_json::Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["reasoning_effort_level"], "extra_high");
        assert_eq!(v["model"], "glm-5.3");
        assert!(v.get("is_max_mode").is_none());

        // Max Mode 单路：注入 is_max_mode:true
        let out = inject(body.clone(), None, true, "glm-5.3", "glm-5.3");
        let v: serde_json::Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["is_max_mode"], true);
        assert!(v.get("reasoning_effort_level").is_none());

        // 支持表外模型不注入（不按名称冒进）
        assert_eq!(inject(body.clone(), None, true, "doubao-seed-code", "doubao-seed-code"), body);

        // canonical 归一：大小写变体同样命中支持表
        let out = inject(body.clone(), None, true, "GLM-5.3", "GLM-5.3");
        let v: serde_json::Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["is_max_mode"], true);

        // 双路并发：单次 parse 同时注入两字段
        let out = inject(body.clone(), Some("high".into()), true, "glm-5.3", "glm-5.3");
        let v: serde_json::Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["reasoning_effort_level"], "high");
        assert_eq!(v["is_max_mode"], true);
        assert_eq!(v["model"], "glm-5.3");

        // body model 回写（issue #38 真机根因）：`-max` 剥离后 body model 仍为
        // 带后缀原名 → 上游收到 xxx-max__dev 报 4001；回写为基名
        let sfx = br#"{"model":"DeepSeek-V4-Flash-Official-max","messages":[]}"#.to_vec();
        let out = inject(sfx.clone(), None, false, "DeepSeek-V4-Flash-Official-max", "DeepSeek-V4-Flash-Official");
        let v: serde_json::Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["model"], "DeepSeek-V4-Flash-Official", "仅回写场景（无注入）也生效");
        let out = inject(sfx, None, true, "DeepSeek-V4-Flash-Official-max", "DeepSeek-V4-Flash-Official");
        let v: serde_json::Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["model"], "DeepSeek-V4-Flash-Official");
        assert_eq!(v["is_max_mode"], true);

        // 非对象 body（数组）→ 原样
        let arr = br#"[1,2,3]"#.to_vec();
        assert_eq!(inject(arr.clone(), Some("high".into()), true, "glm-5.3", "glm-5.3"), arr);

        // 非 JSON body → 原样
        let raw = b"not-json".to_vec();
        assert_eq!(inject(raw.clone(), Some("high".into()), true, "glm-5.3", "glm-5.3"), raw);
    }
}
