//! WorkBuddy 上游请求体改写（T2.1/F-28/F-30 v1.2）
//!
//! 上游 `POST {chatBase}/v2/chat/completions` 为 OpenAI 兼容体，但有四个坑：
//! 1. 拒绝非流式（code 11101）→ 强制 `stream:true`，非流式由本地聚合；
//! 2. `tool_choice` 对象形式报 400 → 归一化为 string；
//! 3. `reasoning_effort` 档位上游不支持时拒答/忽略 → 按目录 supportedEfforts
//!    降级（调用方先用 wb_catalog::resolve_effort 解析，本层只负责注入）；
//! 4. Claude Code 指纹触发腾讯内容审核 → 指纹清洗（身份句改写 + cc_xxx 键值
//!    剥离 + x-anthropic-* 引用剥离）+ 审核模板黑名单最小改写（映射表外置
//!    `wb_template_map.json` 可热更新，§5.5 #9 cat-and-mouse，禁硬编码扩散）。
//!
//! 另：连续同角色消息自动合并（生态实测，§5.8 #9）。

use serde_json::{json, Map, Value};
use std::collections::BTreeMap;
use std::sync::{Mutex, OnceLock};

/// 默认审核模板映射（映射表文件缺失时的内置兜底，§5.5 #9：
/// CLI→CLI tool、based on→built on——任何一字改动即绕过逐字匹配）。
/// Codex 两条身份句前缀不带句号，兼容 GPT-5/GPT-5-Codex 等模型后缀变体。
pub fn default_template_map() -> Vec<(String, String)> {
    vec![
        (
            "You are Claude Code, Anthropic's official CLI for Claude.".to_string(),
            "You are Claude Code, Anthropic's official CLI tool for Claude.".to_string(),
        ),
        (
            "Main branch (you will usually use this with PRs)".to_string(),
            "Default branch (you will usually use this with PRs)".to_string(),
        ),
        (
            "Main branch (you will usually use this for PRs)".to_string(),
            "Default branch (you will usually use this for PRs)".to_string(),
        ),
        // Codex CLI v1 harness：instructions 首句身份声明
        (
            "You are Codex, based on GPT-5".to_string(),
            "You are Codex, built on GPT-5".to_string(),
        ),
        // Codex CLI v2 harness：instructions 首句身份声明
        (
            "You are Codex, an agent based on GPT-5".to_string(),
            "You are Codex, an agent built on GPT-5".to_string(),
        ),
        // Codex CLI v3 harness（9/19 新版 codex.exe 实证）：instructions 首句身份声明
        (
            "You are Codex, a coding agent based on GPT-5".to_string(),
            "You are Codex, a coding agent built on GPT-5".to_string(),
        ),
        // Codex CLI v4 harness（同上新版 codex.exe 实证，CLI 官方 harness）
        (
            "You are a coding agent running in the Codex CLI".to_string(),
            "You are a coding agent working in the Codex CLI".to_string(),
        ),
        // TraeCode harness：system 首句身份声明（日志实证 pool=trae 请求原文，
        // 虽当前未被拦截，预防性兜底——同一指纹句一旦进入风控名单即全量 11128）
        (
            "You are an interactive agent in TraeCode that helps the USER with software engineering tasks.".to_string(),
            "You are an interactive agent running in TraeCode that helps the USER with software engineering tasks.".to_string(),
        ),
        // issue #57 预防性布防：REASONIX/DSH 等第三方客户端指纹句（无真实请求
        // 日志可查证，按常见开源 CLI harness 身份句先布防——未命中即无操作）。
        // 上线后从请求日志（debug）核实触发句，通过 KV wb_template_map.json
        // 热更新迭代精确规则，无须发版
        (
            "You are Cline, a highly skilled software engineer with extensive knowledge".to_string(),
            "You are Cline, a highly capable software engineering assistant with extensive knowledge"
                .to_string(),
        ),
        (
            "You are Roo, a highly skilled software engineer with extensive knowledge".to_string(),
            "You are Roo, a highly capable software engineering assistant with extensive knowledge"
                .to_string(),
        ),
        (
            "You are an interactive CLI agent specializing in software engineering tasks."
                .to_string(),
            "You are an interactive CLI assistant specializing in software engineering tasks."
                .to_string(),
        ),
        // OpenCode harness（公开 prompt 可查证，issue #57 布防）：按 provider
        // 分多套 flavor，首句身份声明各不相同，逐条最小改写（含大小写变体）
        (
            "You are opencode, an interactive CLI tool that helps users with software engineering tasks."
                .to_string(),
            "You are opencode, an interactive CLI assistant that helps users with software engineering tasks."
                .to_string(),
        ),
        (
            "You are OpenCode, You and the user share the same workspace.".to_string(),
            "You are OpenCode, You and the user work in the same workspace.".to_string(),
        ),
        (
            "You are OpenCode, the best coding agent on the planet.".to_string(),
            "You are OpenCode, a top coding agent for software engineering.".to_string(),
        ),
        (
            "You are opencode, an interactive CLI agent specializing in software engineering tasks."
                .to_string(),
            "You are opencode, an interactive CLI assistant specializing in software engineering tasks."
                .to_string(),
        ),
        (
            "You are operating as and within the OpenCode CLI, a terminal-based agentic coding assistant built by OpenAI."
                .to_string(),
            "You are operating as and within the OpenCode CLI, a terminal-based agentic coding tool built by OpenAI."
                .to_string(),
        ),
        // DeepSeek Harness（DSH，2026-10-06 测试机日志实证：pool=trae 空完成影子
        // 风控，4 账号全 healthy 仍全灭；请求日志抓到身份句原文）。首句身份声明 +
        // 模型句 "powered by" 复现（glm 前缀匹配覆盖 5.3/5.3-flash 变体），
        // 改写手法对齐 Codex 规则 based on→built on
        (
            "You are an AI agent powered by DeepSeek Harness.".to_string(),
            "You are an AI agent built on DeepSeek Harness.".to_string(),
        ),
        (
            "You are a coding agent powered by the glm-".to_string(),
            "You are a coding agent built on the glm-".to_string(),
        ),
    ]
}

/// 模板映射文件结构：wb_template_map.json
#[derive(Debug, Default, Clone, serde::Deserialize, serde::Serialize)]
pub struct TemplateMapFile {
    #[serde(default)]
    pub templates: Vec<TemplateRule>,
    #[serde(default)]
    pub updated_at: Option<i64>,
}

#[derive(Debug, Clone, serde::Deserialize, serde::Serialize)]
pub struct TemplateRule {
    pub from: String,
    pub to: String,
}

impl TemplateMapFile {
    /// 转换为 (from, to) 规则表：剔除空 from；全空 → None（调用方走内置兜底）
    pub fn into_rules(self) -> Option<Vec<(String, String)>> {
        let rules: Vec<(String, String)> = self
            .templates
            .into_iter()
            .filter(|r| !r.from.is_empty())
            .map(|r| (r.from, r.to))
            .collect();
        if rules.is_empty() {
            None
        } else {
            Some(rules)
        }
    }
}

/// 模板映射命中计数（issue #57 指纹反查）：
/// 热路径仅内存计数（命中才加锁）；11128 强制清洗重试 / 空完成换号重试等
/// 风控命中路径用 template_hit_note() 导出随日志落盘——ZCode/DSH/REASONIX
/// 等无公开资料客户端的迭代通道：从日志反查精确触发句 → 热更新规则表
fn hit_counter() -> &'static Mutex<BTreeMap<String, u64>> {
    static HITS: OnceLock<Mutex<BTreeMap<String, u64>>> = OnceLock::new();
    HITS.get_or_init(|| Mutex::new(BTreeMap::new()))
}

fn record_hit(from: &str, to: &str) {
    if let Ok(mut m) = hit_counter().lock() {
        *m.entry(format!("{from} → {to}")).or_insert(0) += 1;
    }
}

/// 命中统计全文（"from → to ×N; ..."；无命中返回 None）
pub fn template_hit_summary() -> Option<String> {
    let m = hit_counter().lock().ok()?;
    if m.is_empty() {
        return None;
    }
    Some(
        m.iter()
            .map(|(k, v)| format!("{k} ×{v}"))
            .collect::<Vec<_>>()
            .join("; "),
    )
}

/// 错误日志附注（无命中返回空串）：拼在「空完成 → 换号重试」等 note 之后
pub fn template_hit_note() -> String {
    match template_hit_summary() {
        Some(s) => format!("；模板命中: {s}"),
        None => String::new(),
    }
}

/// 审核模板黑名单最小改写：映射表为空才跳过（不做硬编码关键词预检——
/// 外置映射表新增规则的命中词可能不含内置三短语，预检会永久漏改）；
/// 条目少（个位数），逐条 contains 代价可接受
pub fn apply_template_map(text: &str, templates: &[(String, String)]) -> String {
    if templates.is_empty() {
        return text.to_string();
    }
    let mut out = text.to_string();
    for (from, to) in templates {
        if out.contains(from.as_str()) {
            out = out.replace(from.as_str(), to.as_str());
            record_hit(from, to);
        }
    }
    out
}

/// 剥离 cc_xxx=...; 键值对与 x-anthropic-* 引用（F-30 指纹清洗，零正则依赖）
pub fn strip_cc_fingerprints(text: &str) -> String {
    let needs_check = text.contains("cc_") || text.contains("x-anthropic-");
    if !needs_check {
        return text.to_string();
    }
    let mut out = String::with_capacity(text.len());
    let bytes = text.as_bytes();
    let mut i = 0;
    while i < text.len() {
        let rest = &text[i..];
        let is_cc = rest.starts_with("cc_");
        let is_anthropic = rest.starts_with("x-anthropic-");
        if (is_cc || is_anthropic) && (i == 0 || !is_token_char(bytes[i - 1])) {
            // 键名（token 字符）
            let mut j = i;
            while j < text.len() && is_token_char(bytes[j]) {
                j += 1;
            }
            // P1 修复（误伤回归）：键名后必须跟 `=`/`:` 分隔符（前后允许空白）才算
            // 指纹键值对——裸词（如 "use cc_flags for build" 的 cc_flags）是正常
            // 业务内容，原实现整词删除 + 吞尾随空白，静默损坏用户内容
            let after = &text[j..];
            let t2 = after.trim_start();
            if !t2.starts_with('=') && !t2.starts_with(':') {
                // 非指纹键：按普通文本原样保留整个键名（ASCII token，直接复制）
                out.push_str(&text[i..j]);
                i = j;
                continue;
            }
            let mut end = j;
            if let Some(r) = t2.strip_prefix(['=', ':']) {
                let v = r.trim_start(); // v 是 text 的后缀
                let vs = text.len() - v.len();
                let stop_rel = v
                    .find(|c| matches!(c, ';' | ',' | ' ' | '\n' | '\t'))
                    .unwrap_or(v.len());
                end = vs + stop_rel;
            }
            // 吃掉尾随的分号/逗号/空白（键值对属于指纹痕迹，连逗号一并清除）
            while end < text.len() && matches!(bytes[end], b';' | b',' | b' ' | b'\t') {
                end += 1;
            }
            i = end;
            continue;
        }
        // UTF-8 安全推进
        let ch_len = utf8_len(bytes[i]);
        out.push_str(&text[i..i + ch_len]);
        i += ch_len;
    }
    out
}

fn is_token_char(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_' || b == b'-'
}

fn utf8_len(b: u8) -> usize {
    match b {
        0x00..=0x7F => 1,
        0xC0..=0xDF => 2,
        0xE0..=0xEF => 3,
        _ => 4,
    }
}

/// 对单条消息 content 施加清洗（string 与 text blocks 两种形态）
fn sanitize_content(content: &mut Value, templates: &[(String, String)], sanitize: bool) {
    match content {
        Value::String(s) => {
            let mut t = if sanitize { strip_cc_fingerprints(s) } else { s.clone() };
            if sanitize {
                t = apply_template_map(&t, templates);
            }
            *s = t;
        }
        Value::Array(blocks) => {
            for b in blocks.iter_mut() {
                if let Some(Value::String(t)) = b.get_mut("text") {
                    let mut v = if sanitize { strip_cc_fingerprints(t) } else { t.clone() };
                    if sanitize {
                        v = apply_template_map(&v, templates);
                    }
                    *t = v;
                }
            }
        }
        _ => {}
    }
}

/// OpenAI 请求体 → WB /v2/chat/completions 请求体改写。
///
/// `account_uid`：发起请求的账号 uid（账号池体系）。非空时注入顶层
/// `prompt_cache_key`（agent2api normalize.rs 情报互证，2026-10-03）：命中上游
/// 前缀缓存可带来数量级的费用差；**键必须按账号硬隔离**——跨账号命中前缀缓存
/// 等于把 A 账号对话内容泄露给 B 账号（作者实测教训），故键首段为账号 uid。
pub fn prepare_wb_chat_body(
    src: &[u8],
    model: &str,
    account_uid: &str,
    conv_id: &str,
    effort: Option<&str>,
    sanitize: bool,
    templates: &[(String, String)],
) -> Vec<u8> {
    let mut obj: Value = match serde_json::from_slice(src) {
        Ok(v) => v,
        Err(_) => return src.to_vec(),
    };
    let m = match obj.as_object_mut() {
        Some(m) => m,
        None => return src.to_vec(),
    };

    // 模型归一化（目录 id 为小写规范名）
    m.insert("model".into(), json!(model));

    // 连续同角色消息合并 + 指纹清洗。
    // role:"tool" 一律不参与合并（无论当前还是上一条）：tool_call_id 必须逐条
    // 保留，合并会丢失 id 使上游无法把结果对齐到对应调用
    if let Some(msgs) = m.get_mut("messages").and_then(|v| v.as_array_mut()) {
        let mut merged: Vec<Value> = Vec::with_capacity(msgs.len());
        for msg in msgs.drain(..) {
            let role = msg.get("role").and_then(|r| r.as_str()).unwrap_or("").to_string();
            let mergeable = !role.is_empty() && role != "tool";
            if mergeable {
                if let Some(last) = merged.last_mut() {
                    let last_role = last.get("role").and_then(|r| r.as_str()).unwrap_or("");
                    if !last_role.is_empty() && last_role != "tool" && role == last_role {
                        merge_message(last, msg);
                        continue;
                    }
                }
            }
            merged.push(msg);
        }
        for msg in merged.iter_mut() {
            if let Some(c) = msg.get_mut("content") {
                sanitize_content(c, templates, sanitize);
            }
            // 指纹清洗覆盖 tool_calls[].function.arguments（审核模板最小改写；
            // 不套用 strip_cc_fingerprints——其删段语义可能破坏 JSON 结构）
            if let Some(tcs) = msg.get_mut("tool_calls").and_then(|t| t.as_array_mut()) {
                for tc in tcs.iter_mut() {
                    if let Some(Value::String(s)) = tc
                        .get_mut("function")
                        .and_then(|f| f.get_mut("arguments"))
                    {
                        if sanitize {
                            *s = apply_template_map(s, templates);
                        }
                    }
                }
            }
        }
        m.insert("messages".into(), Value::Array(merged));
    }

    // 指纹清洗覆盖 tools[].function.description（审核模板最小改写）：
    // CLI harness 可能将身份句/生态术语嵌入工具描述，是消息体清洗的绕过通道
    if sanitize {
        if let Some(tools) = m.get_mut("tools").and_then(|t| t.as_array_mut()) {
            for tool in tools.iter_mut() {
                if let Some(Value::String(d)) = tool
                    .get_mut("function")
                    .and_then(|f| f.get_mut("description"))
                {
                    *d = apply_template_map(d, templates);
                }
            }
        }
    }

    normalize_tool_choice(m);

    // 首条消息必须为 system（上游 Go struct 硬校验，否则 400；agent2api 实测
    // 情报 2026-10-03）。在合并/清洗之后执行：合并不改变首条相对位置，但调用方
    // 可能产出 user-first 请求体，此处统一兜底
    ensure_leading_system_message(m);

    // 强制流式（上游拒绝非流式，code 11101）
    m.insert("stream".into(), json!(true));

    // 会话 id（粘性绑定 / 上游会话归属）
    if !conv_id.is_empty() {
        m.insert("conversation_id".into(), json!(conv_id));
    }

    // prompt_cache_key：按账号硬隔离的上游前缀缓存键（见函数头注释）；
    // uid 缺失（测试/异常路径）不注入，宁缺勿造
    if !account_uid.is_empty() {
        m.insert("prompt_cache_key".into(), json!(prompt_cache_key(account_uid, conv_id)));
    }

    // reasoning_effort：调用方已按目录降级，这里只注入非空值
    if let Some(e) = effort.map(str::trim).filter(|s| !s.is_empty()) {
        m.insert("reasoning_effort".into(), json!(e));
    } else {
        m.remove("reasoning_effort");
    }

    serde_json::to_vec(&obj).unwrap_or_else(|_| src.to_vec())
}

/// 上游前缀缓存键：`wb-<uid 前 8 位>-<sha256(uid|conv)[0..16]>`。
/// 同账号 + 同会话稳定命中缓存；不同账号键必不同（硬隔离，防对话内容跨账号泄露）。
fn prompt_cache_key(account_uid: &str, conv_id: &str) -> String {
    use sha2::{Digest, Sha256};
    let uid8: String = account_uid.chars().take(8).collect();
    let mut h = Sha256::new();
    h.update(account_uid.as_bytes());
    h.update(b"|");
    h.update(conv_id.as_bytes());
    let hex: String = h.finalize().iter().map(|b| format!("{b:02x}")).collect();
    format!("wb-{uid8}-{}", &hex[..16.min(hex.len())])
}

/// 首条消息 system 兜底（agent2api workbuddy.rs ensure_leading_system_message
/// 同款，2026-10-03 情报）：上游要求首条必为 system 否则 400；首条为 user/
/// assistant 时前置一条中性兜底。messages 为空/缺失时不动（让上游自身的
/// 参数校验报错，避免掩盖调用方 bug）。
fn ensure_leading_system_message(m: &mut Map<String, Value>) {
    const FALLBACK_SYSTEM: &str = "你是一个得力助手";
    let Some(msgs) = m.get_mut("messages").and_then(|v| v.as_array_mut()) else {
        return;
    };
    let first_is_system = msgs
        .first()
        .and_then(|msg| msg.get("role"))
        .and_then(|r| r.as_str())
        .map(|r| r.eq_ignore_ascii_case("system"))
        .unwrap_or(false);
    if !msgs.is_empty() && !first_is_system {
        msgs.insert(0, json!({"role": "system", "content": FALLBACK_SYSTEM}));
    }
}

/// 同角色合并：string/text 拼接；tool_calls 追加；其余字段保留首个
fn merge_message(base: &mut Value, extra: Value) {
    let content_b = extra.get("content").cloned().unwrap_or(Value::Null);
    if !content_b.is_null() {
        // 目标 content 缺失/为 null：直接采用新值
        if base.get("content").map_or(true, |c| c.is_null()) {
            base["content"] = content_b;
        } else {
            join_content(base.get_mut("content").unwrap(), content_b);
        }
    }
    if let Some(tcs) = extra.get("tool_calls").and_then(|t| t.as_array()).cloned() {
        match base.get_mut("tool_calls").and_then(|t| t.as_array_mut()) {
            Some(arr) => arr.extend(tcs),
            None => base["tool_calls"] = Value::Array(tcs),
        }
    }
}

/// content 拼接：string↔string 加空行拼接；string 进数组追加 text 块；数组合并
fn join_content(base: &mut Value, extra: Value) {
    match extra {
        Value::String(y) => match base {
            Value::String(x) => {
                let mut s = x.clone();
                if !s.is_empty() && !y.is_empty() {
                    s.push_str("\n\n");
                }
                s.push_str(&y);
                *x = s;
            }
            Value::Array(x) => x.push(json!({"type": "text", "text": y})),
            _ => {}
        },
        Value::Array(y) => match base {
            Value::Array(x) => x.extend(y),
            Value::String(x) => {
                let old = x.clone();
                let mut blocks = vec![json!({"type": "text", "text": old})];
                blocks.extend(y);
                *base = Value::Array(blocks);
            }
            _ => {}
        },
        _ => {}
    }
}

/// tool_choice 归一化（对象形式上游报 400 code=11101）：
/// {"type":"function","function":{"name":X}} → "X"；auto/none/required 原样 string；
/// 带 function.name 的对象（含未知 type 形态）一律归一为该 name；
/// 其余未知形态归 auto
pub fn normalize_tool_choice(m: &mut Map<String, Value>) {
    let tc = match m.remove("tool_choice") {
        Some(v) => v,
        None => return,
    };
    match tc {
        Value::String(_) => {
            m.insert("tool_choice".into(), tc);
        }
        Value::Object(map) => {
            let typ = map
                .get("type")
                .and_then(|t| t.as_str())
                .unwrap_or("auto")
                .to_lowercase();
            let name = map
                .get("function")
                .and_then(|f| f.get("name"))
                .and_then(|n| n.as_str())
                .or_else(|| map.get("name").and_then(|n| n.as_str()))
                .map(str::trim)
                .filter(|s| !s.is_empty());
            let value = match name {
                // 带 name 的对象：无论 type 为何（function/未知形态）都保留指定意图
                Some(n) => n.to_string(),
                None => match typ.as_str() {
                    "none" => "none".to_string(),
                    "any" | "required" => "required".to_string(),
                    // auto 与其余未知形态一律归 auto
                    _ => "auto".to_string(),
                },
            };
            m.insert("tool_choice".into(), json!(value));
        }
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    const NO_TPL: &[(String, String)] = &[];

    #[test]
    fn template_hit_counter_records_and_exports() {
        // 命中即计数（issue #57 指纹反查）：summary/note 导出 from→to 与次数
        let tpls = vec![("FP_PROBE_FROM".to_string(), "FP_PROBE_TO".to_string())];
        let out = apply_template_map("before FP_PROBE_FROM after", &tpls);
        assert_eq!(out, "before FP_PROBE_TO after");
        let summary = template_hit_summary().expect("命中后 summary 不应为空");
        assert!(summary.contains("FP_PROBE_FROM → FP_PROBE_TO"), "{summary}");
        assert!(summary.contains("×1"), "{summary}");
        let note = template_hit_note();
        assert!(note.contains("模板命中: "), "{note}");
        assert!(note.contains("FP_PROBE_FROM → FP_PROBE_TO"), "{note}");
        // 未命中不计数：只含上面那一条
        let _ = apply_template_map("no match here", &tpls);
        let again = template_hit_summary().unwrap();
        assert_eq!(again.matches("FP_PROBE_FROM → FP_PROBE_TO").count(), 1);
    }

    fn rewrite(v: Value, effort: Option<&str>) -> Value {
        let src = serde_json::to_vec(&v).unwrap();
        let out = prepare_wb_chat_body(&src, "glm-5.3", "4487568582777872", "conv-1", effort, true, NO_TPL);
        serde_json::from_slice(&out).unwrap()
    }

    /// prompt_cache_key 按账号硬隔离：同账号+同会话稳定；跨账号键必不同
    #[test]
    fn prompt_cache_key_hard_isolated_per_account() {
        let src = json!({"messages":[{"role":"system","content":"s"}]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let out = prepare_wb_chat_body(&src_bytes, "m", "4487568582777872", "conv-1", None, false, NO_TPL);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let key = v["prompt_cache_key"].as_str().unwrap();
        assert!(key.starts_with("wb-44875685-"), "键首段为账号 uid 前 8 位: {key}");
        // 同账号同会话：稳定（可重复调用命中同一缓存键）
        let out2 = prepare_wb_chat_body(&src_bytes, "m", "4487568582777872", "conv-1", None, false, NO_TPL);
        let v2: Value = serde_json::from_slice(&out2).unwrap();
        assert_eq!(v2["prompt_cache_key"], v["prompt_cache_key"]);
        // 跨账号：键必不同（硬隔离——跨账号命中前缀缓存 = 对话内容泄露）
        let out3 = prepare_wb_chat_body(&src_bytes, "m", "1335050000000000", "conv-1", None, false, NO_TPL);
        let v3: Value = serde_json::from_slice(&out3).unwrap();
        assert_ne!(v3["prompt_cache_key"], v["prompt_cache_key"]);
        assert!(v3["prompt_cache_key"].as_str().unwrap().starts_with("wb-13350500-"));
        // uid 缺失不注入（宁缺勿造）
        let out4 = prepare_wb_chat_body(&src_bytes, "m", "", "conv-1", None, false, NO_TPL);
        let v4: Value = serde_json::from_slice(&out4).unwrap();
        assert!(v4.get("prompt_cache_key").is_none());
    }

    /// 首条消息 system 兜底：user-first 前置中性 system；system-first 不动；
    /// 空 messages 不动（让上游参数校验报错）
    #[test]
    fn leading_system_message_ensured() {
        let src = json!({"messages":[{"role":"user","content":"hi"}]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "c", None, false, NO_TPL);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let msgs = v["messages"].as_array().unwrap();
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[0]["role"], json!("system"));
        assert!(!msgs[0]["content"].as_str().unwrap().is_empty());
        assert_eq!(msgs[1], json!({"role":"user","content":"hi"}));

        // system-first 不重复注入
        let src = json!({"messages":[{"role":"system","content":"真实系统提示"},{"role":"user","content":"hi"}]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "c", None, false, NO_TPL);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let msgs = v["messages"].as_array().unwrap();
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[0]["content"], json!("真实系统提示"));

        // 空 messages 不注入
        let src = json!({"messages":[]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "c", None, false, NO_TPL);
        let v: Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["messages"].as_array().unwrap().len(), 0);
    }

    #[test]
    fn forces_stream_and_sets_conversation() {
        let out = rewrite(json!({"model":"glm-5.3","stream":false,"messages":[]}), None);
        assert_eq!(out["stream"], json!(true));
        assert_eq!(out["conversation_id"], json!("conv-1"));
        assert_eq!(out["model"], json!("glm-5.3"));
    }

    #[test]
    fn tool_choice_object_becomes_string() {
        let out = rewrite(
            json!({"messages":[],"tool_choice":{"type":"function","function":{"name":"get_weather"}}}),
            None,
        );
        assert_eq!(out["tool_choice"], json!("get_weather"));
        let out = rewrite(json!({"messages":[],"tool_choice":{"type":"any"}}), None);
        assert_eq!(out["tool_choice"], json!("required"));
        let out = rewrite(json!({"messages":[],"tool_choice":{"type":"none"}}), None);
        assert_eq!(out["tool_choice"], json!("none"));
        // string 原样保留
        let out = rewrite(json!({"messages":[],"tool_choice":"auto"}), None);
        assert_eq!(out["tool_choice"], json!("auto"));
    }

    #[test]
    fn effort_injected_or_removed() {
        let out = rewrite(json!({"messages":[],"reasoning_effort":"xhigh"}), Some("medium"));
        assert_eq!(out["reasoning_effort"], json!("medium"));
        let out = rewrite(json!({"messages":[],"reasoning_effort":"high"}), None);
        assert!(out.get("reasoning_effort").is_none());
    }

    #[test]
    fn merges_consecutive_same_role() {
        // 输入自带首条 system：不触发兜底注入，合并语义保持原断言
        let out = rewrite(
            json!({"messages":[
                {"role":"system","content":"sys"},
                {"role":"user","content":"第一段"},
                {"role":"user","content":"第二段"},
                {"role":"assistant","content":"回复"},
            ]}),
            None,
        );
        let msgs = out["messages"].as_array().unwrap();
        assert_eq!(msgs.len(), 3);
        assert_eq!(msgs[1]["content"], json!("第一段\n\n第二段"));
    }

    #[test]
    fn template_blacklist_minimal_rewrite() {
        let tpl = default_template_map();
        let cc = "You are Claude Code, Anthropic's official CLI for Claude.";
        let out = apply_template_map(cc, &tpl);
        assert_ne!(out, cc);
        assert!(out.contains("CLI tool"));
        assert!(!out.contains("official CLI for Claude."));
        // Main branch → Default branch（两种原文写法都覆盖）
        assert!(apply_template_map("Main branch (you will usually use this for PRs)", &tpl)
            .starts_with("Default branch"));
        assert!(apply_template_map("Main branch (you will usually use this with PRs)", &tpl)
            .starts_with("Default branch"));
        // 无指纹内容零改动（预检短路）
        let plain = "普通中文内容不清洗";
        assert_eq!(apply_template_map(plain, &tpl), plain);
    }

    #[test]
    fn template_rewrites_deepseek_harness_identity() {
        // DSH（DeepSeek Harness）身份句：2026-10-06 测试机空完成影子风控实证，
        // 首句 + 模型句 "powered by" 均需改写（glm- 前缀匹配覆盖模型变体）
        let tpl = default_template_map();
        let dsh = "You are an AI agent powered by DeepSeek Harness.\n\nYou are a coding agent powered by the glm-5.3-flash model.";
        let out = apply_template_map(dsh, &tpl);
        assert!(out.contains("built on DeepSeek Harness."), "{out}");
        assert!(out.contains("built on the glm-5.3-flash model."), "{out}");
        assert!(!out.contains("powered by"), "{out}");
    }

    #[test]
    fn sanitize_strips_cc_and_anthropic_tokens() {
        assert_eq!(strip_cc_fingerprints("ok cc_user=abc; tail"), "ok tail");
        assert_eq!(strip_cc_fingerprints("a cc_env=X:1,b"), "a b");
        assert_eq!(
            strip_cc_fingerprints("see x-anthropic-beta: prompt-caching end"),
            "see end"
        );
        // 普通下划线词不受影响
        assert_eq!(strip_cc_fingerprints("success_count=3"), "success_count=3");
        // P1 修复回归：裸 cc_ 词（无 =/: 值分隔符）属正常业务内容，不得删除
        assert_eq!(
            strip_cc_fingerprints("use cc_flags for build"),
            "use cc_flags for build"
        );
        assert_eq!(
            strip_cc_fingerprints("add cc_config: check crate cc_deps next"),
            "add crate cc_deps next"
        );
        // 键名在文本结尾（无值可取）同样保留
        assert_eq!(
            strip_cc_fingerprints("ends with cc_config"),
            "ends with cc_config"
        );
    }

    #[test]
    fn sanitize_applied_to_message_content() {
        let src = json!({"messages":[{"role":"system","content":"You are Claude Code, Anthropic's official CLI for Claude."}]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let tpl = default_template_map();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, true, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let s = v["messages"][0]["content"].as_str().unwrap();
        assert!(s.contains("CLI tool"));
        assert!(!s.contains("official CLI for Claude."));
        // sanitize 关闭时跳过该预处理（与指纹清洗开关联动 §5.5 #9）
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, false, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        assert_eq!(v["messages"][0]["content"], json!("You are Claude Code, Anthropic's official CLI for Claude."));
    }

    /// 回归：连续两条 role:"tool" 消息不合并，tool_call_id 逐条保留；
    /// 连续 role:"user" 仍合并（既有语义）；tool 之后跟 user 也不得并入 tool
    #[test]
    fn tool_messages_never_merge_and_keep_call_ids() {
        // 输入自带首条 system：不触发兜底注入
        let out = rewrite(json!({"messages":[
            {"role":"system","content":"sys"},
            {"role":"assistant","content":null,
             "tool_calls":[{"id":"c1","type":"function","function":{"name":"f","arguments":"{}"}}]},
            {"role":"tool","tool_call_id":"c1","content":"r1"},
            {"role":"tool","tool_call_id":"c2","content":"r2"},
        ]}), None);
        let msgs = out["messages"].as_array().unwrap();
        assert_eq!(msgs.len(), 4, "连续两条 role:tool 不合并");
        assert_eq!(msgs[2]["tool_call_id"], json!("c1"));
        assert_eq!(msgs[3]["tool_call_id"], json!("c2"));
        // 连续 user 仍合并（system 兜底注入后共 2 条）
        let out = rewrite(json!({"messages":[
            {"role":"system","content":"sys"},
            {"role":"user","content":"a"},
            {"role":"user","content":"b"},
        ]}), None);
        let msgs = out["messages"].as_array().unwrap();
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[1]["content"], json!("a\n\nb"));
        // tool 之后的 user 消息不得并入 tool 消息
        let out = rewrite(json!({"messages":[
            {"role":"system","content":"sys"},
            {"role":"tool","tool_call_id":"c1","content":"r"},
            {"role":"user","content":"继续"},
        ]}), None);
        assert_eq!(out["messages"].as_array().unwrap().len(), 3);
    }

    /// 外置映射表新增规则不再被硬编码预检短路：规则命中词不含内置三短语也生效
    #[test]
    fn external_template_rules_apply_without_hardcoded_precheck() {
        let tpl = vec![("FooBar".to_string(), "Baz".to_string())];
        assert_eq!(apply_template_map("hello FooBar world", &tpl), "hello Baz world");
        // 空映射表 → 原样
        assert_eq!(apply_template_map("Claude Code", NO_TPL), "Claude Code");
        // 无规则命中的内容零改动（原「预检短路」语义由无命中自然保证）
        let plain = "普通中文内容不清洗";
        assert_eq!(apply_template_map(plain, &default_template_map()), plain);
    }

    /// 指纹清洗覆盖 tool_calls[].function.arguments（最小改写、JSON 结构不破坏）
    #[test]
    fn sanitize_covers_tool_call_arguments() {
        let src = json!({"messages":[
            {"role":"system","content":"sys"},
            {"role":"assistant","content":null,"tool_calls":[
                {"id":"c1","type":"function","function":{"name":"note",
                 "arguments":"{\"prompt\":\"You are Claude Code, Anthropic's official CLI for Claude.\"}"}}
            ]}
        ]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let tpl = default_template_map();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, true, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let args = v["messages"][1]["tool_calls"][0]["function"]["arguments"].as_str().unwrap();
        assert!(args.contains("CLI tool"));
        assert!(!args.contains("official CLI for Claude."));
        // arguments 仍是合法 JSON（结构未被清洗破坏）
        let parsed: Value = serde_json::from_str(args).unwrap();
        assert_eq!(
            parsed["prompt"],
            json!("You are Claude Code, Anthropic's official CLI tool for Claude.")
        );
        // sanitize=false 不清洗
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, false, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        assert!(v["messages"][1]["tool_calls"][0]["function"]["arguments"]
            .as_str()
            .unwrap()
            .contains("official CLI for Claude."));
    }

    /// tool_choice 带 function.name 的对象（含未知 type / 缺 type 形态）归一为该 name
    #[test]
    fn tool_choice_name_bearing_objects_normalize_to_name() {
        // 缺 type 的 function 对象 → name（旧实现误归 auto 丢失指定意图）
        let out = rewrite(json!({"messages":[],"tool_choice":{"function":{"name":"get_weather"}}}), None);
        assert_eq!(out["tool_choice"], json!("get_weather"));
        // 未知 type 但带 function.name → name
        let out = rewrite(json!({"messages":[],"tool_choice":{"type":"custom","function":{"name":"t"}}}), None);
        assert_eq!(out["tool_choice"], json!("t"));
        // 既有形态回归：type=function → name
        let out = rewrite(json!({"messages":[],"tool_choice":{"type":"function","function":{"name":"f"}}}), None);
        assert_eq!(out["tool_choice"], json!("f"));
        // 无 name 的未知形态 → auto
        let out = rewrite(json!({"messages":[],"tool_choice":{"type":"weird"}}), None);
        assert_eq!(out["tool_choice"], json!("auto"));
    }

    /// Codex CLI 身份句指纹清洗（v1/v2 harness 首句，最小改写绕过逐字匹配）
    #[test]
    fn codex_identity_sentences_minimal_rewrite() {
        let tpl = default_template_map();
        // v1 harness 首句（gpt-5/5.1/5.3-codex 通用）
        let v1 = "You are Codex, based on GPT-5. You are running as a coding agent in the Codex CLI on a user's computer.";
        let out = apply_template_map(v1, &tpl);
        assert_ne!(out, v1);
        assert!(out.starts_with("You are Codex, built on GPT-5."));
        assert!(!out.contains("based on GPT-5"));
        // v2 harness 首句（新版 harness）
        let v2 = "You are Codex, an agent based on GPT-5. You and the user share one workspace.";
        let out = apply_template_map(v2, &tpl);
        assert_ne!(out, v2);
        assert!(out.starts_with("You are Codex, an agent built on GPT-5."));
        assert!(!out.contains("based on GPT-5"));
        // v3 harness 首句（9/19 新版 codex.exe 实证）
        let v3 = "You are Codex, a coding agent based on GPT-5. You and the user share the same workspace and collaborate to achieve the user's goals.";
        let out = apply_template_map(v3, &tpl);
        assert_ne!(out, v3);
        assert!(out.starts_with("You are Codex, a coding agent built on GPT-5."));
        assert!(!out.contains("based on GPT-5"));
        // v4 harness 首句（同上新版 codex.exe 实证，CLI 官方 harness）
        let v4 = "You are a coding agent running in the Codex CLI, a terminal-based coding assistant.";
        let out = apply_template_map(v4, &tpl);
        assert_ne!(out, v4);
        assert!(out.starts_with("You are a coding agent working in the Codex CLI"));
        assert!(!out.contains("running in the Codex CLI"));
        // 两条规则互不误伤（v1 改写结果不含 v2 触发词，反之亦然）
        assert_eq!(
            apply_template_map("You are Codex, built on GPT-5.", &tpl),
            "You are Codex, built on GPT-5."
        );
    }

    /// Codex instructions → system 消息端到端清洗（responses_to_chat 产物形态）
    #[test]
    fn sanitize_covers_codex_instructions_system_message() {
        let src = json!({"messages":[
            {"role":"system","content":"You are Codex, based on GPT-5. You are running as a coding agent in the Codex CLI on a user's computer."},
            {"role":"user","content":"帮我写个函数"},
        ]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let tpl = default_template_map();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, true, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let s = v["messages"][0]["content"].as_str().unwrap();
        assert!(s.contains("built on GPT-5"));
        assert!(!s.contains("based on GPT-5"));
        // user 消息不受影响
        assert_eq!(v["messages"][1]["content"], json!("帮我写个函数"));
        // sanitize=false 原样透传（清洗开关联动）
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, false, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        assert!(v["messages"][0]["content"].as_str().unwrap().contains("based on GPT-5"));
    }

    /// TraeCode 身份句最小改写（日志实证 pool=trae system 首句原文，预防性兜底）
    #[test]
    fn trae_identity_sentence_minimal_rewrite() {
        let tpl = default_template_map();
        let src = "You are an interactive agent in TraeCode that helps the USER with software engineering tasks. Use the instructions below and the tools available to you to assist the USER.";
        let out = apply_template_map(src, &tpl);
        assert_ne!(out, src);
        assert!(out.contains("interactive agent running in TraeCode"));
        assert!(!out.contains("agent in TraeCode"));
        // 改写结果不再命中触发词（幂等安全）
        assert_eq!(apply_template_map(&out, &tpl), out);
    }

    /// TraeCode system 消息端到端清洗（pool=trae 请求形态）
    #[test]
    fn sanitize_covers_trae_system_message() {
        let src = json!({"messages":[
            {"role":"system","content":"You are an interactive agent in TraeCode that helps the USER with software engineering tasks. Use the instructions below and the tools available to you to assist the USER."},
            {"role":"user","content":"fix the bug"},
        ]});
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let tpl = default_template_map();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, true, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let s = v["messages"][0]["content"].as_str().unwrap();
        assert!(s.contains("agent running in TraeCode"));
        assert!(!s.contains("agent in TraeCode"));
        // user 消息不受影响
        assert_eq!(v["messages"][1]["content"], json!("fix the bug"));
    }

    /// tools[].function.description 指纹清洗（CLI harness 将身份句嵌入工具
    /// 描述的绕过通道——消息体清洗覆盖不到，必须单独处理）
    #[test]
    fn sanitize_covers_tool_function_description() {
        let src = json!({
            "messages": [{"role":"user","content":"hi"}],
            "tools": [
                {"type":"function","function":{
                    "name":"web_search",
                    "description":"Web search tool. You are Codex, based on GPT-5. You are Claude Code, Anthropic's official CLI for Claude. You are an interactive agent in TraeCode that helps the USER with software engineering tasks.",
                    "parameters":{"type":"object","properties":{"query":{"type":"string"}}}
                }},
                {"type":"function","function":{
                    "name":"read_file",
                    "description":"Reads a file from disk.",
                    "parameters":{"type":"object","properties":{"path":{"type":"string"}}}
                }},
                // 非 function 形态工具（Responses 原生 web_search）不误伤
                {"type":"web_search"}
            ]
        });
        let src_bytes = serde_json::to_vec(&src).unwrap();
        let tpl = default_template_map();
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, true, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let tools = v["tools"].as_array().unwrap();

        // 工具 1：三条指纹全部改写（规则逐字匹配完整身份句）
        let d0 = tools[0]["function"]["description"].as_str().unwrap();
        assert!(d0.contains("You are Codex, built on GPT-5"));
        assert!(d0.contains("official CLI tool for Claude"));
        assert!(d0.contains("interactive agent running in TraeCode"));
        assert!(!d0.contains("based on GPT-5"));
        assert!(!d0.contains("CLI for Claude"));
        assert!(!d0.contains("agent in TraeCode"));

        // 工具 2：无指纹原样保留
        assert_eq!(tools[1]["function"]["description"], json!("Reads a file from disk."));
        // 工具 3：无 description 字段的工具不误伤
        assert_eq!(tools[2]["type"], json!("web_search"));
        assert!(tools[2].get("function").is_none());

        // sanitize=false 原样透传（清洗开关联动）
        let out = prepare_wb_chat_body(&src_bytes, "m", "", "", None, false, &tpl);
        let v: Value = serde_json::from_slice(&out).unwrap();
        let d0 = v["tools"][0]["function"]["description"].as_str().unwrap();
        assert!(d0.contains("based on GPT-5"));
    }
}
